import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Pure Glassic Symbol Mark for Al-Jazari AI:
// No text, only a 3D crystal glass emblem featuring the iconic 'A' monogram,
// gyroscopic automation orbit with circuit nodes (Al-Jazari engineering homage),
// refractive glass specular highlights, and brilliant cyan-blue luminous core.
const glassicSymbolSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <!-- Background Glass Slate Radial Gradient -->
    <radialGradient id="bgSphere" cx="50%" cy="45%" r="75%">
      <stop offset="0%" stop-color="#0F2042"/>
      <stop offset="45%" stop-color="#091328"/>
      <stop offset="85%" stop-color="#050B18"/>
      <stop offset="100%" stop-color="#020610"/>
    </radialGradient>

    <!-- 3D Glass Prism Gradients for 'A' -->
    <linearGradient id="prismLeft" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#E0F2FE"/>
      <stop offset="25%" stop-color="#38BDF8"/>
      <stop offset="65%" stop-color="#0284C7"/>
      <stop offset="100%" stop-color="#0369A1"/>
    </linearGradient>

    <linearGradient id="prismRight" x1="100%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#BAE6FD"/>
      <stop offset="30%" stop-color="#0EA5E9"/>
      <stop offset="70%" stop-color="#2563EB"/>
      <stop offset="100%" stop-color="#1D4ED8"/>
    </linearGradient>

    <!-- Glass Orbital Astrolabe / Circuit Ring -->
    <linearGradient id="orbitGlow" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#67E8F9"/>
      <stop offset="35%" stop-color="#38BDF8"/>
      <stop offset="70%" stop-color="#0EA5E9"/>
      <stop offset="100%" stop-color="#0284C7"/>
    </linearGradient>

    <!-- Inner Core Bioluminescence -->
    <radialGradient id="innerBloom" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#38BDF8" stop-opacity="0.85"/>
      <stop offset="45%" stop-color="#0EA5E9" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="#0284C7" stop-opacity="0"/>
    </radialGradient>

    <!-- Specular Highlight Linear Gradient -->
    <linearGradient id="glassSpecular" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.6"/>
      <stop offset="40%" stop-color="#38BDF8" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#FFFFFF" stop-opacity="0"/>
    </linearGradient>

    <!-- Glow Filter -->
    <filter id="bloom" x="-30%" y="-30%" width="160%" height="160%">
      <feGaussianBlur stdDeviation="9" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>

    <filter id="subtleGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="4" result="blur2"/>
      <feComposite in="SourceGraphic" in2="blur2" operator="over"/>
    </filter>
  </defs>

  <!-- Outer Glassic Squircle Vessel -->
  <rect width="512" height="512" rx="118" fill="url(#bgSphere)"/>
  
  <!-- Outer Refractive Glass Edge -->
  <rect x="3" y="3" width="506" height="506" rx="115" fill="none" stroke="url(#glassSpecular)" stroke-width="2.5" stroke-opacity="0.75"/>
  <rect x="7" y="7" width="498" height="498" rx="112" fill="none" stroke="#0284C7" stroke-width="1.2" stroke-opacity="0.3"/>

  <!-- Ambient Internal Crystal Sphere Glow -->
  <circle cx="256" cy="245" r="185" fill="url(#innerBloom)" filter="url(#bloom)"/>

  <!-- Precision Astrolabe / Engineering Concentric Rings (Al-Jazari homage) -->
  <circle cx="256" cy="245" r="155" fill="none" stroke="#38BDF8" stroke-width="1" stroke-dasharray="3 7" stroke-opacity="0.4"/>
  <circle cx="256" cy="245" r="195" fill="none" stroke="#0284C7" stroke-width="1" stroke-dasharray="2 12" stroke-opacity="0.25"/>

  <!-- Back Side of the 3D Gyroscopic Circuit Orbit -->
  <ellipse cx="256" cy="265" rx="180" ry="62" transform="rotate(-22 256 265)" fill="none" stroke="url(#orbitGlow)" stroke-width="12" stroke-linecap="round" stroke-opacity="0.6" filter="url(#bloom)"/>

  <!-- Circuit Trace Nodes on Orbit -->
  <g transform="rotate(-22 256 265)">
    <line x1="410" y1="265" x2="455" y2="265" stroke="#E0F2FE" stroke-width="5" stroke-linecap="round"/>
    <circle cx="458" cy="265" r="6.5" fill="#E0F2FE" filter="url(#subtleGlow)"/>
    <line x1="422" y1="242" x2="448" y2="220" stroke="#38BDF8" stroke-width="4" stroke-linecap="round"/>
    <circle cx="452" cy="216" r="5" fill="#38BDF8"/>
    <line x1="420" y1="288" x2="446" y2="310" stroke="#38BDF8" stroke-width="4" stroke-linecap="round"/>
    <circle cx="450" cy="314" r="5" fill="#38BDF8"/>
  </g>

  <!-- The 3D Glassic 'A' Monogram Backbone -->
  <!-- Left Wing / Facet -->
  <path d="M256 95 L140 370 L195 370 L228 290 L256 290 Z" fill="url(#prismLeft)" filter="url(#bloom)"/>
  
  <!-- Right Wing / Facet -->
  <path d="M256 95 L256 290 L284 290 L317 370 L372 370 Z" fill="url(#prismRight)" filter="url(#bloom)"/>

  <!-- Sharp Apex Specular Glint -->
  <polygon points="256,95 240,165 272,165" fill="#FFFFFF" fill-opacity="0.4"/>
  <circle cx="256" cy="98" r="5" fill="#FFFFFF" filter="url(#bloom)"/>

  <!-- Inner Triangular Glass Portal -->
  <polygon points="256,170 232,245 280,245" fill="#040916" stroke="#38BDF8" stroke-width="2" stroke-opacity="0.6"/>

  <!-- Floating Crystal Core Diamond (Symbolizing mechanical precision & AI intelligence) -->
  <g transform="translate(256, 312)">
    <polygon points="0,-22 18,0 0,22 -18,0" fill="#E0F2FE" filter="url(#subtleGlow)"/>
    <polygon points="0,-16 13,0 0,16 -13,0" fill="#38BDF8"/>
    <circle cx="0" cy="0" r="4" fill="#FFFFFF"/>
  </g>

  <!-- Front Segment of Orbiting Gyroscopic Ring for 3D Layering Depth -->
  <path d="M96 308 Q 256 375 410 270" fill="none" stroke="url(#orbitGlow)" stroke-width="15" stroke-linecap="round" filter="url(#bloom)"/>
  <path d="M110 305 Q 256 370 395 272" fill="none" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round" stroke-opacity="0.8"/>

  <!-- Top Glass Sheen (Curved highlight reflecting light on the glass surface) -->
  <path d="M30 40 Q 256 120 482 40 C 495 55 500 75 500 95 C 430 180 82 180 12 95 C 12 75 18 55 30 40 Z" fill="url(#glassSpecular)" opacity="0.45"/>
</svg>`;

async function run() {
  fs.writeFileSync(path.join(publicDir, 'logo.svg'), glassicSymbolSvg);
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), glassicSymbolSvg);

  const buffer = Buffer.from(glassicSymbolSvg);

  await sharp(buffer).resize(600, 600).png().toFile(path.join(publicDir, 'logo.png'));
  await sharp(buffer).resize(512, 512).png().toFile(path.join(publicDir, 'pwa-512x512.png'));
  await sharp(buffer).resize(192, 192).png().toFile(path.join(publicDir, 'pwa-192x192.png'));
  await sharp(buffer).resize(512, 512).png().toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));
  await sharp(buffer).resize(180, 180).png().toFile(path.join(publicDir, 'apple-touch-icon.png'));
  await sharp(buffer).resize(64, 64).png().toFile(path.join(publicDir, 'favicon.ico'));

  console.log('Pure glassic classic emblem generated successfully without text!');
}

run().catch(console.error);
