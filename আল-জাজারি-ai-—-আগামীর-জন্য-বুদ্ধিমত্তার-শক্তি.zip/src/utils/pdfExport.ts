import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export interface PdfExportOptions {
  content: string;
  assistantName?: string;
  categoryName?: string;
  timestamp?: number;
  documentTitle?: string;
}

/**
 * Format timestamp into Bengali date string
 */
function formatBengaliDate(timestamp: number): string {
  try {
    const date = new Date(timestamp);
    const months = [
      'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    const hours = date.getHours();
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'অপরাহ্ন' : 'পূর্বাহ্ন';
    const formattedHour = hours % 12 || 12;

    return `${day} ${month} ${year}, ${formattedHour}:${minutes} ${ampm}`;
  } catch {
    return new Date(timestamp).toLocaleString();
  }
}

/**
 * Formats markdown-like text to clean structured HTML
 */
function formatContentToHtml(raw: string): string {
  if (!raw) return '';

  const lines = raw.split('\n');
  const htmlParts: string[] = [];
  let inList = false;

  for (const line of lines) {
    const trimmed = line.trim();

    if (!trimmed) {
      if (inList) {
        htmlParts.push('</ul>');
        inList = false;
      }
      htmlParts.push('<div style="height: 10px;"></div>');
      continue;
    }

    if (trimmed.startsWith('### ')) {
      if (inList) { htmlParts.push('</ul>'); inList = false; }
      htmlParts.push(`<h3 style="font-size: 16px; font-weight: 800; color: #1e3a8a; margin: 14px 0 6px 0; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px;">${trimmed.substring(4)}</h3>`);
    } else if (trimmed.startsWith('## ')) {
      if (inList) { htmlParts.push('</ul>'); inList = false; }
      htmlParts.push(`<h2 style="font-size: 18px; font-weight: 800; color: #0f172a; margin: 18px 0 8px 0; border-bottom: 2px solid #cbd5e1; padding-bottom: 4px;">${trimmed.substring(3)}</h2>`);
    } else if (trimmed.startsWith('# ')) {
      if (inList) { htmlParts.push('</ul>'); inList = false; }
      htmlParts.push(`<h1 style="font-size: 20px; font-weight: 900; color: #0f172a; margin: 20px 0 10px 0;">${trimmed.substring(2)}</h1>`);
    } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      if (!inList) {
        htmlParts.push('<ul style="margin: 6px 0; padding-left: 20px; list-style-type: disc;">');
        inList = true;
      }
      const itemText = trimmed.substring(2).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      htmlParts.push(`<li style="font-size: 13px; line-height: 1.7; color: #334155; margin-bottom: 4px;">${itemText}</li>`);
    } else {
      if (inList) {
        htmlParts.push('</ul>');
        inList = false;
      }
      const pText = trimmed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      htmlParts.push(`<p style="font-size: 13px; line-height: 1.8; color: #334155; margin: 6px 0;">${pText}</p>`);
    }
  }

  if (inList) {
    htmlParts.push('</ul>');
  }

  return htmlParts.join('');
}

/**
 * Exports AI output to a structured high-resolution PDF document
 */
export async function exportToStructuredPdf(options: PdfExportOptions): Promise<void> {
  const {
    content,
    assistantName = 'ক্যারিয়ার ও এআই বিশেষজ্ঞ',
    categoryName = 'জেনারেল ডকুমেন্টেশন',
    timestamp = Date.now(),
    documentTitle = 'আল-জাজারি AI পেশাদার প্রতিবেদন',
  } = options;

  const formattedDate = formatBengaliDate(timestamp);
  const docId = `DOC_${Date.now().toString(36).toUpperCase()}_${Math.floor(1000 + Math.random() * 9000)}`;
  const bodyHtml = formatContentToHtml(content);

  // Create an offscreen rendering container
  const container = document.createElement('div');
  container.id = 'al-jazari-pdf-render-box';
  container.style.position = 'fixed';
  container.style.left = '-9999px';
  container.style.top = '0';
  container.style.width = '794px'; // Standard A4 width at 96 DPI
  container.style.minHeight = '1123px'; // Standard A4 height at 96 DPI
  container.style.backgroundColor = '#ffffff';
  container.style.color = '#0f172a';
  container.style.fontFamily = "'Hind Siliguri', 'Segoe UI', -apple-system, Roboto, sans-serif";
  container.style.padding = '44px 50px';
  container.style.boxSizing = 'border-box';
  container.style.zIndex = '-9999';

  container.innerHTML = `
    <!-- PDF Header Letterhead -->
    <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #2563eb; padding-bottom: 16px; margin-bottom: 20px;">
      <div style="display: flex; align-items: center; gap: 14px;">
        <div style="width: 44px; height: 44px; border-radius: 12px; background: linear-gradient(135deg, #1d4ed8, #4338ca); display: flex; align-items: center; justify-content: center; color: #ffffff; font-size: 22px; font-weight: 900; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
          জ
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <h1 style="font-size: 20px; font-weight: 900; color: #0f172a; margin: 0; line-height: 1;">
              আল-জাজারি এআই
            </h1>
            <span style="background-color: #2563eb; color: #ffffff; font-size: 10px; font-weight: 800; padding: 2px 6px; border-radius: 4px; text-transform: uppercase;">
              PRO
            </span>
          </div>
          <p style="font-size: 11px; color: #64748b; margin: 4px 0 0 0; font-weight: 600;">
            আগামীর জন্য বুদ্ধিমত্তার শক্তি • প্রফেশনাল ডকুমেন্ট এক্সপোর্ট
          </p>
        </div>
      </div>

      <div style="text-align: right;">
        <div style="font-size: 10px; font-weight: 800; color: #059669; background: #ecfdf5; border: 1px solid #a7f3d0; padding: 3px 8px; border-radius: 9999px; display: inline-block; margin-bottom: 4px;">
          ✓ এআই ভেরিফাইড ডকুমেন্ট
        </div>
        <p style="font-size: 10px; color: #64748b; margin: 0; font-family: monospace;">
          ডকুমেন্ট আইডি: ${docId}
        </p>
      </div>
    </div>

    <!-- Metadata Banner: Assistant Name, Category & Timestamp -->
    <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px 16px; margin-bottom: 22px; display: flex; justify-content: space-between; align-items: center; font-size: 12px;">
      <div>
        <span style="color: #64748b; font-weight: 600;">এআই অ্যাসিস্ট্যান্ট:</span>
        <strong style="color: #1e3a8a; margin-left: 6px; font-size: 13px;">${assistantName}</strong>
      </div>
      <div>
        <span style="color: #64748b; font-weight: 600;">ক্যাটাগরি:</span>
        <span style="color: #334155; font-weight: 700; margin-left: 6px; background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 6px;">${categoryName}</span>
      </div>
      <div>
        <span style="color: #64748b; font-weight: 600;">তারিখ ও সময়:</span>
        <strong style="color: #0f172a; margin-left: 6px; font-family: 'Hind Siliguri', sans-serif;">${formattedDate}</strong>
      </div>
    </div>

    <!-- Document Main Heading -->
    <div style="margin-bottom: 16px;">
      <h2 style="font-size: 17px; font-weight: 900; color: #0f172a; margin: 0 0 6px 0; border-left: 4px solid #2563eb; padding-left: 10px;">
        ${documentTitle}
      </h2>
    </div>

    <!-- Structured Content Body -->
    <div style="line-height: 1.8; color: #1e293b; font-size: 13px; text-align: justify;">
      ${bodyHtml}
    </div>

    <!-- Document Footer -->
    <div style="margin-top: 40px; padding-top: 14px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; font-size: 10px; color: #94a3b8;">
      <div>
        © আল-জাজারি AI (Al-Jazari AI) • সর্বস্বত্ব সংরক্ষিত • শতভাগ সুরক্ষিত ক্লাউড প্ল্যাটফর্ম
      </div>
      <div style="font-weight: 700; color: #64748b;">
        পৃষ্ঠা ১ / ১ • জেনারেটেড: ${new Date().toLocaleTimeString()}
      </div>
    </div>
  `;

  document.body.appendChild(container);

  try {
    // Render HTML container to high-resolution canvas
    const canvas = await html2canvas(container, {
      scale: 2, // 2x DPI for crisp font rendering
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.95);

    // Create jsPDF in portrait A4 orientation (mm)
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = 210; // A4 mm
    const pdfHeight = 297; // A4 mm
    const imgWidth = pdfWidth;
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    // Handle single or multi-page PDF cleanly
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
    heightLeft -= pdfHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pdfHeight;
    }

    // Direct download without blocked popups or window.open
    const filename = `al-jazari-output-${Date.now()}.pdf`;
    pdf.save(filename);
  } finally {
    // Cleanup temporary DOM element
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}
