import React, { useState, useEffect } from 'react';
import {
  CategoryId,
  ToneId,
  GenerationHistoryItem,
  AppTab,
  AppLanguage,
  ThemeMode,
  AttachedFile,
  AssistantInfo,
  SecurityViolation,
  DiagnosticSeverity,
} from './types';
import { Header } from './components/Header';
import { UserTelcoCard } from './components/UserTelcoCard';
import { CategoryCards } from './components/CategoryCards';
import { FormInterface } from './components/FormInterface';
import { ResultDisplay } from './components/ResultDisplay';
import { AssistantsModule } from './components/AssistantsModule';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { HistoryTab } from './components/HistoryTab';
import { SettingsTab } from './components/SettingsTab';
import { AdBanner } from './components/AdBanner';
import { BottomNav } from './components/BottomNav';
import { RechargeModal } from './components/RechargeModal';
import { ShareModal } from './components/ShareModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { HowItWorksModal } from './components/HowItWorksModal';
import { AdminDiagnosticModal } from './components/AdminDiagnosticModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { audio } from './utils/audio';
import { LOADING_PUNCHLINES } from './data/categories';
import confetti from 'canvas-confetti';
import { Sparkles, ChevronRight, ShieldCheck, Image as ImageIcon } from 'lucide-react';

const STORAGE_KEYS = {
  CREDITS: 'al_jazari_credits_v1',
  HISTORY: 'al_jazari_history_v1',
  SOUND: 'al_jazari_sound_v1',
  LANGUAGE: 'al_jazari_lang_v1',
  THEME: 'al_jazari_theme_v1',
  ACTIVE_ASSISTANT: 'al_jazari_active_assistant_v1',
  USER_STATUS: 'al_jazari_user_status_v1',
  LAST_TRANSACTION: 'al_jazari_last_tran_v1',
};

// High-resolution natural scenery backgrounds (Silky smooth crossfade every 12 seconds)
const NATURE_SCENES = [
  {
    id: 'green_hills',
    name: 'সবুজ পাহাড়ি প্রান্তর',
    url: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1920&q=85',
  },
  {
    id: 'alpine_valley',
    name: 'পাইন বন ও উপত্যকা',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=85',
  },
  {
    id: 'misty_mountains',
    name: 'কুয়াশাচ্ছন্ন নীলগিরি',
    url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1920&q=85',
  },
  {
    id: 'sunlit_meadow',
    name: 'রোদেলা সবুজ চারণভূমি',
    url: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&w=1920&q=85',
  },
  {
    id: 'emerald_highlands',
    name: 'শান্ত গোধূলি পাহাড়',
    url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1920&q=85',
  },
];

export default function App() {
  const [credits, setCredits] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CREDITS);
    return saved !== null ? Number(saved) : 500;
  });

  const [category, setCategory] = useState<CategoryId>('student');
  const [tone, setTone] = useState<ToneId>('formal');
  const [prompt, setPrompt] = useState<string>('');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [securityViolation, setSecurityViolation] = useState<SecurityViolation | null>(null);
  const [latencyMs, setLatencyMs] = useState<number | undefined>(undefined);
  const [estimatedTokens, setEstimatedTokens] = useState<number | undefined>(undefined);
  const [outputAssistantName, setOutputAssistantName] = useState<string | undefined>(undefined);

  // Active Bottom Tab: workspace | assistants | analytics | history | settings
  const [activeTab, setActiveTab] = useState<AppTab>('workspace');

  // Multi-modal state
  const [attachedFile, setAttachedFile] = useState<AttachedFile | null>(null);

  // Language state (BN / EN)
  const [language, setLanguage] = useState<AppLanguage>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LANGUAGE);
    return saved === 'en' ? 'en' : 'bn';
  });

  // Theme state (Dark / Light)
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    return saved === 'light' ? 'light' : 'dark';
  });

  // Modals & Drawers
  const [isRechargeOpen, setIsRechargeOpen] = useState<boolean>(false);
  const [isShareOpen, setIsShareOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState<boolean>(false);

  // User Payment & Subscription Status (PRO সক্রিয় / সাধারণ)
  const [userStatus, setUserStatus] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.USER_STATUS) || 'PRO সক্রিয়';
  });
  const [lastTransactionId, setLastTransactionId] = useState<string | null>(() => {
    return localStorage.getItem(STORAGE_KEYS.LAST_TRANSACTION) || 'TXN_1792414428';
  });
  const [paymentToast, setPaymentToast] = useState<{
    type: 'success' | 'error' | 'info';
    title: string;
    message: string;
  } | null>(null);

  // Admin Diagnostic System State
  const [isAdminDiagnosticOpen, setIsAdminDiagnosticOpen] = useState<boolean>(false);
  const [activeDiagnosticIssueId, setActiveDiagnosticIssueId] = useState<string | null>(null);
  const [activeDiagnosticCount, setActiveDiagnosticCount] = useState<number>(0);
  const [diagnosticSeverity, setDiagnosticSeverity] = useState<DiagnosticSeverity>('healthy');

  // Natural Landscapes Auto-Rotation state (Cycles landscapes every 12 seconds)
  const [sceneIdx, setSceneIdx] = useState(0);

  // Sound toggle
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SOUND);
    return saved !== null ? saved === 'true' : true;
  });

  // History state
  const [history, setHistory] = useState<GenerationHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HISTORY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Assistants State
  const [assistants, setAssistants] = useState<AssistantInfo[]>([]);
  const [activeAssistant, setActiveAssistant] = useState<AssistantInfo | null>(null);

  // Dynamic loading message index
  const [loadingMsgIdx, setLoadingMsgIdx] = useState(0);

  // Sync Credits
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CREDITS, credits.toString());
  }, [credits]);

  // Sync Sound
  useEffect(() => {
    audio.enabled = soundEnabled;
    localStorage.setItem(STORAGE_KEYS.SOUND, soundEnabled.toString());
  }, [soundEnabled]);

  // Sync History
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
  }, [history]);

  // Sync Language
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, language);
  }, [language]);

  // Sync Theme
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [theme]);

  // Fetch Assistants on Mount
  useEffect(() => {
    const fetchAssistants = async () => {
      try {
        const res = await fetch('/api/assistants');
        if (res.ok) {
          const data = await res.json();
          if (data.assistants && data.assistants.length > 0) {
            setAssistants(data.assistants);
            const savedActiveId = localStorage.getItem(STORAGE_KEYS.ACTIVE_ASSISTANT);
            if (savedActiveId) {
              const matched = data.assistants.find((a: AssistantInfo) => a.id === savedActiveId);
              if (matched) setActiveAssistant(matched);
            }
          }
        }
      } catch (err) {
        console.warn('Failed to load assistants from API:', err);
      }
    };
    fetchAssistants();
  }, []);

  // Fetch live User Subscription & Payment Status from Database / Supabase
  useEffect(() => {
    const fetchUserPaymentStatus = async () => {
      try {
        const res = await fetch('/api/payment/user-status');
        if (res.ok) {
          const data = await res.json();
          if (data.status) {
            setUserStatus(data.status);
            localStorage.setItem(STORAGE_KEYS.USER_STATUS, data.status);
          }
          if (data.lastTransactionId) {
            setLastTransactionId(data.lastTransactionId);
            localStorage.setItem(STORAGE_KEYS.LAST_TRANSACTION, data.lastTransactionId);
          }
        }
      } catch (err) {
        console.warn('Could not sync payment status:', err);
      }
    };
    fetchUserPaymentStatus();
  }, []);

  // Handle SSLCommerz Gateway Redirect Callbacks (?payment=success|fail|cancel)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const payment = params.get('payment');
    const tranId = params.get('tran_id');
    const amount = params.get('amount');
    const pkg = params.get('pkg');

    if (payment === 'success') {
      setUserStatus('PRO সক্রিয়');
      localStorage.setItem(STORAGE_KEYS.USER_STATUS, 'PRO সক্রিয়');
      if (tranId) {
        setLastTransactionId(tranId);
        localStorage.setItem(STORAGE_KEYS.LAST_TRANSACTION, tranId);
      }
      setCredits((prev) => prev + 150);
      audio.playCash();

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#3B82F6', '#10B981', '#6366F1', '#F59E0B'],
        });
      } catch {
        // ignore
      }

      setPaymentToast({
        type: 'success',
        title: 'পেমেন্ট সফল হয়েছে!',
        message: `SSLCommerz স্যান্ডবক্স ট্রানজেকশন সফল: ${tranId || ''} (৳${amount || '100.00'})। আপনার অ্যাকাউন্ট 'PRO সক্রিয়' করা হয়েছে।`,
      });

      // Clear search query params cleanly
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (payment === 'fail') {
      setPaymentToast({
        type: 'error',
        title: 'পেমেন্ট ব্যর্থ হয়েছে',
        message: `SSLCommerz ট্রানজেকশন সম্পন্ন করা যায়নি (আইডি: ${tranId || ''})। অনুগ্রহ করে আবার চেষ্টা করুন।`,
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (payment === 'cancel') {
      setPaymentToast({
        type: 'info',
        title: 'পেমেন্ট বাতিল করা হয়েছে',
        message: `SSLCommerz স্যান্ডবক্স পেমেন্ট প্রক্রিয়া বাতিল করা হয়েছে (আইডি: ${tranId || ''})।`,
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  // Fetch live system health & diagnostic summary
  const fetchDiagnosticsSummary = async () => {
    try {
      const res = await fetch('/api/admin/diagnostics');
      if (res.ok) {
        const data = await res.json();
        setActiveDiagnosticCount(data.activeIssues?.length || 0);
        setDiagnosticSeverity(data.status || 'healthy');
      }
    } catch {
      // offline or unreachable
      setDiagnosticSeverity('warning');
    }
  };

  useEffect(() => {
    fetchDiagnosticsSummary();
    const interval = setInterval(fetchDiagnosticsSummary, 15000);
    return () => clearInterval(interval);
  }, []);

  // Rotate natural scenery every 12 seconds with silky smooth crossfade
  useEffect(() => {
    const timer = setInterval(() => {
      setSceneIdx((prev) => (prev + 1) % NATURE_SCENES.length);
    }, 12000);
    return () => clearInterval(timer);
  }, []);

  // Loading punchlines rotator
  useEffect(() => {
    if (!isLoading) return;
    const interval = setInterval(() => {
      setLoadingMsgIdx((prev) => (prev + 1) % LOADING_PUNCHLINES.length);
    }, 2400);
    return () => clearInterval(interval);
  }, [isLoading]);

  // Assistant selection
  const handleSelectAssistant = (ast: AssistantInfo) => {
    setActiveAssistant(ast);
    localStorage.setItem(STORAGE_KEYS.ACTIVE_ASSISTANT, ast.id);
    setCategory(ast.category);
    setTone(ast.tone);
  };

  // Assistant creation
  const handleCreateAssistant = async (data: Omit<AssistantInfo, 'id'>) => {
    const res = await fetch('/api/assistants', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'সহকারী সংরক্ষণ করা যায়নি।');
    }

    const json = await res.json();
    if (json.assistant) {
      setAssistants((prev) => [json.assistant, ...prev]);
      setActiveAssistant(json.assistant);
      localStorage.setItem(STORAGE_KEYS.ACTIVE_ASSISTANT, json.assistant.id);
    }
  };

  // Assistant deletion
  const handleDeleteAssistant = async (id: string) => {
    await fetch(`/api/assistants/${id}`, { method: 'DELETE' });
    setAssistants((prev) => prev.filter((a) => a.id !== id));
    if (activeAssistant?.id === id) {
      setActiveAssistant(null);
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_ASSISTANT);
    }
  };

  // Handle generation action (incorporates security guardrail check)
  const handleGenerate = async () => {
    if (!prompt.trim() && !attachedFile) return;

    setIsLoading(true);
    setError(null);
    setSecurityViolation(null);
    setLoadingMsgIdx(0);
    audio.playTick();

    try {
      const payload: Record<string, unknown> = {
        prompt: prompt.trim() || 'সংযুক্ত ফাইলটির পেশাদার ও বিশদ বিশ্লেষণ প্রদান করুন।',
        category,
        tone,
        language,
      };

      if (activeAssistant) {
        payload.assistantId = activeAssistant.id;
        payload.customSystemInstruction = activeAssistant.systemPrompt;
      }

      if (attachedFile) {
        payload.fileAttachment = {
          name: attachedFile.name,
          type: attachedFile.type,
          base64: attachedFile.dataUrl,
        };
      }

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => ({}));

      // ==========================================
      // BACKEND SECURITY THREAT WARNING HANDLER
      // ==========================================
      if (data.isSecurityViolation) {
        setSecurityViolation({
          isSecurityViolation: true,
          threatType: data.threatType || 'hacking',
          threatName: data.threatName,
          title: data.title || 'নিরাপত্তা সতর্কতা: অননুমোদিত সাইবার কার্যকলাপ শনাক্ত হয়েছে',
          warningMessage: data.warningMessage,
          warningMessageEn: data.warningMessageEn,
          safetyAdvice: data.safetyAdvice,
          timestamp: data.timestamp || Date.now(),
        });
        setResult(null);
        setIsLoading(false);
        audio.playTick();

        setTimeout(() => {
          const resultEl = document.getElementById('result-section');
          if (resultEl) resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 80);
        return;
      }

      if (!response.ok) {
        if (data.diagnostic?.id) {
          setActiveDiagnosticIssueId(data.diagnostic.id);
          setActiveDiagnosticCount((prev) => Math.max(1, prev + 1));
          setDiagnosticSeverity(data.diagnostic.severity || 'warning');
        }
        throw new Error(data.error || 'অনুরোধটি সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।');
      }

      const generatedContent = data.result;
      setResult(generatedContent);
      setLatencyMs(data.latencyMs);
      setEstimatedTokens(data.estimatedTokens);
      setOutputAssistantName(data.assistantName || activeAssistant?.name);
      setIsLoading(false);
      audio.playSuccess();

      try {
        confetti({
          particleCount: 45,
          spread: 60,
          origin: { y: 0.7 },
          colors: ['#3B82F6', '#6366F1', '#10B981', '#F59E0B'],
        });
      } catch {
        // ignore
      }

      const newItem: GenerationHistoryItem = {
        id: `gen_${Date.now()}`,
        timestamp: Date.now(),
        category,
        prompt: prompt.trim() || (attachedFile ? `ফাইল: ${attachedFile.name}` : ''),
        result: generatedContent,
        tone,
        assistantId: activeAssistant?.id,
        assistantName: data.assistantName || activeAssistant?.name,
        latencyMs: data.latencyMs,
        estimatedTokens: data.estimatedTokens,
        fileAttachment: attachedFile ? { name: attachedFile.name, type: attachedFile.type } : undefined,
      };

      setHistory((prev) => [newItem, ...prev.slice(0, 49)]);

      setTimeout(() => {
        const resultEl = document.getElementById('result-section');
        if (resultEl) {
          resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'অনুরোধটি সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।';
      setError(message);
      setIsLoading(false);

      // Log client error to backend diagnostics
      fetch('/api/admin/diagnostics/log-error', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: message, context: 'AI Generation Workspace' }),
      })
        .then((r) => r.json())
        .then((d) => {
          if (d.issue?.id) {
            setActiveDiagnosticIssueId(d.issue.id);
            setActiveDiagnosticCount((prev) => Math.max(1, prev + 1));
            setDiagnosticSeverity(d.issue.severity || 'warning');
          }
        })
        .catch(() => {});
    }
  };

  const handleSelectQuickPrompt = (quickPrompt: string, catId: CategoryId) => {
    setCategory(catId);
    setPrompt(quickPrompt);
  };

  const handleRechargeSuccess = (creditsToAdd: number) => {
    setCredits((prev) => prev + creditsToAdd);
    setError(null);
  };

  const handleSelectHistoryItem = (item: GenerationHistoryItem) => {
    setCategory(item.category);
    setPrompt(item.prompt);
    setResult(item.result);
    setTone(item.tone);
    setError(null);
    setSecurityViolation(null);
    if (item.assistantId) {
      const found = assistants.find((a) => a.id === item.assistantId);
      if (found) setActiveAssistant(found);
    }
  };

  const handleToggleBookmark = (id?: string) => {
    setHistory((prev) =>
      prev.map((item) => {
        if (id && item.id === id) {
          return { ...item, isBookmarked: !item.isBookmarked };
        }
        if (!id && result && item.result === result) {
          return { ...item, isBookmarked: !item.isBookmarked };
        }
        return item;
      })
    );
  };

  const handleDeleteHistoryItem = (id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleFeedback = async (rating: 'like' | 'dislike') => {
    try {
      await fetch('/api/analytics/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating, resultExcerpt: result?.slice(0, 80) }),
      });
    } catch {
      // ignore
    }
  };

  const currentResultItem = history.find((h) => h.result === result);
  const currentScene = NATURE_SCENES[sceneIdx];
  const userBookmarksCount = history.filter((h) => h.isBookmarked).length;

  return (
    <div className="min-h-screen text-slate-900 flex justify-center font-sans selection:bg-blue-600 selection:text-white relative overflow-x-hidden">
      {/* 
        NATURAL LANDSCAPE BACKGROUND ROTATOR (Smooth crossfade every 12 seconds)
      */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        {NATURE_SCENES.map((scene, idx) => (
          <div
            key={scene.id}
            className={`absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out ${
              idx === sceneIdx ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
            }`}
            style={{
              backgroundImage: `url(${scene.url})`,
              transitionProperty: 'opacity, transform',
              transitionDuration: '1600ms',
            }}
          />
        ))}
        {/* Daylight high-contrast filter */}
        <div className="absolute inset-0 bg-slate-900/10 backdrop-blur-[2px]" />
      </div>

      {/* Floating Minimal Glass Slab Frame */}
      <div className="w-full max-w-md min-h-screen minimal-glass-slab relative flex flex-col pb-24 shadow-2xl z-10 my-0 sm:my-3 sm:rounded-[36px] overflow-hidden">
        
        {/* Top Header — Clean, spacious, NO overlapping, NO diagnostics on main canvas */}
        <Header
          onOpenRecharge={() => setIsRechargeOpen(true)}
          onOpenHistory={() => setIsHistoryOpen(true)}
          historyCount={history.length}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled((prev) => !prev)}
          theme={theme}
          onToggleTheme={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
          userStatus={userStatus}
        />

        {/* Scenic View Switcher Pill */}
        <div className="px-4 pt-2.5 pb-1 flex items-center justify-between text-[11px] text-slate-600">
          <button
            onClick={() => {
              audio.playTick();
              setSceneIdx((prev) => (prev + 1) % NATURE_SCENES.length);
            }}
            className="inline-flex items-center gap-1.5 minimal-pill px-2.5 py-1 rounded-full text-slate-700 font-bold transition shadow-sm cursor-pointer hover:border-blue-400"
            title="পরবর্তী প্রাকৃতিক দৃশ্য দেখুন"
          >
            <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
            <span>দৃশ্যপট: {currentScene.name}</span>
          </button>

          <span className="text-[10px] text-slate-500 font-semibold">
            স্বয়ংক্রিয় দৃশ্যপট
          </span>
        </div>

        {/* Main Content Area Routed by Active Tab */}
        <main className="flex-1 px-4 py-2 space-y-4">
          
          {/* SSLCommerz Payment Notification Toast Banner */}
          {paymentToast && (
            <div
              className={`p-3.5 rounded-2xl flex items-start justify-between gap-3 text-xs shadow-md border animate-in fade-in transition ${
                paymentToast.type === 'success'
                  ? 'bg-emerald-50/95 text-emerald-950 border-emerald-300'
                  : paymentToast.type === 'error'
                  ? 'bg-rose-50/95 text-rose-950 border-rose-300'
                  : 'bg-blue-50/95 text-blue-950 border-blue-300'
              }`}
            >
              <div className="space-y-0.5 min-w-0">
                <p className="font-black text-sm">{paymentToast.title}</p>
                <p className="font-medium text-xs leading-relaxed">{paymentToast.message}</p>
              </div>
              <button
                onClick={() => setPaymentToast(null)}
                className="p-1 rounded-lg hover:bg-black/10 transition cursor-pointer shrink-0 text-slate-500 font-bold"
              >
                ✕
              </button>
            </div>
          )}

          {/* TAB 1: WORKSPACE */}
          {activeTab === 'workspace' && (
            <>
              {/* 1. Main Hero Status Card */}
              <UserTelcoCard
                credits={credits}
                onOpenRecharge={() => setIsRechargeOpen(true)}
                historyCount={history.length}
                onOpenGuide={() => setIsHowItWorksOpen(true)}
                userStatus={userStatus}
                lastTransactionId={lastTransactionId}
              />

              {/* 2. Essential AI Category Selector (2x2 Grid) */}
              <CategoryCards
                selectedCategory={category}
                onSelectCategory={(catId) => setCategory(catId)}
                onSelectQuickPrompt={handleSelectQuickPrompt}
              />

              {/* 3. One-Click Multi-modal Form Workspace */}
              <FormInterface
                category={category}
                tone={tone}
                prompt={prompt}
                onChangePrompt={setPrompt}
                onChangeTone={setTone}
                onSubmit={handleGenerate}
                isLoading={isLoading}
                credits={credits}
                onOpenRecharge={() => setIsRechargeOpen(true)}
                attachedFile={attachedFile}
                onAttachFile={setAttachedFile}
                language={language}
                onToggleLanguage={() => setLanguage((prev) => (prev === 'bn' ? 'en' : 'bn'))}
                activeAssistant={activeAssistant}
                onOpenAssistants={() => setActiveTab('assistants')}
              />

              {/* 4. Results Panel (Supports Cyber Warning, 1-Click Copy, PDF/TXT Export, Bookmarks) */}
              <div id="result-section">
                <ResultDisplay
                  isLoading={isLoading}
                  error={error}
                  result={result}
                  securityViolation={securityViolation}
                  onRetry={handleGenerate}
                  onClearSecurityWarning={() => setSecurityViolation(null)}
                  onOpenShare={() => setIsShareOpen(true)}
                  loadingMessage={LOADING_PUNCHLINES[loadingMsgIdx]}
                  isBookmarked={Boolean(currentResultItem?.isBookmarked)}
                  onToggleBookmark={() => handleToggleBookmark()}
                  latencyMs={latencyMs}
                  estimatedTokens={estimatedTokens}
                  assistantName={outputAssistantName}
                  onFeedback={handleFeedback}
                />
              </div>

              {/* 5. Promotional & Feature Resource Banner */}
              <AdBanner
                onOpenRecharge={() => setIsRechargeOpen(true)}
                onSelectPrompt={handleSelectQuickPrompt}
              />

              {/* 6. Lower Section: Security & Privacy */}
              <div className="p-4 rounded-3xl minimal-card text-left space-y-2 border border-slate-200/80">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>এন্টারপ্রাইজ সাপোর্ট ও নিরাপত্তা</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setIsHowItWorksOpen(true)}
                    className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <span>নির্দেশিকা</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  আল-জাজারি AI শতভাগ ক্লাউড-এনক্রিপ্টেড। আপনার প্রজেক্ট ও তথ্যের সর্বোচ্চ গোপনীয়তা এবং স্বয়ংক্রিয় সাইবার হুমকি প্রতিরোধ নিশ্চিত করা হয়।
                </p>
              </div>
            </>
          )}

          {/* TAB 2: MY ASSISTANTS (PHASE 1) */}
          {activeTab === 'assistants' && (
            <AssistantsModule
              assistants={assistants}
              activeAssistantId={activeAssistant?.id || null}
              onSelectAssistant={handleSelectAssistant}
              onCreateAssistant={handleCreateAssistant}
              onDeleteAssistant={handleDeleteAssistant}
              onGoToWorkspace={() => setActiveTab('workspace')}
            />
          )}

          {/* TAB 3: ANALYTICS & SECURITY */}
          {activeTab === 'analytics' && (
            <AnalyticsDashboard
              userGenerationsCount={history.length}
              userBookmarksCount={userBookmarksCount}
              onOpenDiagnostics={() => {
                audio.playTick();
                setIsAdminDiagnosticOpen(true);
              }}
            />
          )}

          {/* TAB 4: HISTORY & BOOKMARKS */}
          {activeTab === 'history' && (
            <HistoryTab
              history={history}
              onSelectHistoryItem={handleSelectHistoryItem}
              onClearHistory={handleClearHistory}
              onToggleBookmark={handleToggleBookmark}
              onDeleteHistoryItem={handleDeleteHistoryItem}
              onGoToWorkspace={() => setActiveTab('workspace')}
            />
          )}

          {/* TAB 5: SETTINGS & GUIDE */}
          {activeTab === 'settings' && (
            <SettingsTab
              language={language}
              onToggleLanguage={() => setLanguage((prev) => (prev === 'bn' ? 'en' : 'bn'))}
              soundEnabled={soundEnabled}
              onToggleSound={() => setSoundEnabled((prev) => !prev)}
              theme={theme}
              onToggleTheme={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
              onOpenGuide={() => setIsHowItWorksOpen(true)}
              onOpenRecharge={() => setIsRechargeOpen(true)}
              onOpenDiagnostics={() => {
                audio.playTick();
                setIsAdminDiagnosticOpen(true);
              }}
            />
          )}

          {/* Mini Footer inside glass container */}
          <footer className="py-4 text-center text-[11px] text-slate-500 space-y-1">
            <p className="font-bold text-slate-700">
              আল-জাজারি AI • আগামীর জন্য বুদ্ধিমত্তার শক্তি
            </p>
            <p className="flex items-center justify-center gap-1 text-slate-500 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 inline" />
              <span>পেশাদার এআই অটোমেশন ও সাইবার সিকিউরিটি শিল্ড</span>
            </p>
          </footer>
        </main>

        {/* 7. Fixed Bottom Navigation Bar (5 Functional Tabs) */}
        <BottomNav
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          historyCount={history.length}
        />

        {/* Modals & Sheets */}
        <RechargeModal
          isOpen={isRechargeOpen}
          onClose={() => setIsRechargeOpen(false)}
          onRechargeSuccess={handleRechargeSuccess}
          currentCredits={credits}
          userStatus={userStatus}
          lastTransactionId={lastTransactionId}
        />

        <ShareModal
          isOpen={isShareOpen}
          onClose={() => setIsShareOpen(false)}
          resultText={result || prompt}
        />

        <HistoryDrawer
          isOpen={isHistoryOpen}
          onClose={() => setIsHistoryOpen(false)}
          history={history}
          onSelectHistoryItem={handleSelectHistoryItem}
          onClearHistory={handleClearHistory}
        />

        <HowItWorksModal
          isOpen={isHowItWorksOpen}
          onClose={() => setIsHowItWorksOpen(false)}
          onStartNow={() => {
            setIsHowItWorksOpen(false);
            setActiveTab('workspace');
            const formEl = document.querySelector('textarea');
            if (formEl) formEl.focus();
          }}
        />

        {/* Admin Diagnostic & Instruction System Modal */}
        <AdminDiagnosticModal
          isOpen={isAdminDiagnosticOpen}
          onClose={() => setIsAdminDiagnosticOpen(false)}
          activeIssueId={activeDiagnosticIssueId}
          onRecheckRequested={fetchDiagnosticsSummary}
        />

        <OfflineIndicator />
      </div>
    </div>
  );
}
