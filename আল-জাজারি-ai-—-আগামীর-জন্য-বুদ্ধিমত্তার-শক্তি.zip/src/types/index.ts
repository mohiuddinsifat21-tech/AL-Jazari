export type CategoryId = 'student' | 'career' | 'freelance' | 'creator';

export type ToneId = 'formal' | 'academic' | 'business' | 'concise';

export type AppTab = 'workspace' | 'assistants' | 'history' | 'analytics' | 'settings';

export type AppLanguage = 'bn' | 'en';

export type ThemeMode = 'dark' | 'light';

export interface CategoryInfo {
  id: CategoryId;
  number: string;
  name: string;
  subtitle: string;
  icon: string;
  badge: string;
  badgeColor: string;
  placeholder: string;
  purpose: string;
  quickPrompts: string[];
}

export interface ToneInfo {
  id: ToneId;
  name: string;
  description: string;
  badge: string;
}

export interface AssistantInfo {
  id: string;
  name: string;
  role: string;
  description: string;
  icon: string;
  category: CategoryId;
  tone: ToneId;
  systemPrompt: string;
  isCustom?: boolean;
  createdAt?: number;
  usageCount?: number;
}

export interface RechargePack {
  id: string;
  price: number;
  credits: number;
  quotaLabel?: string;
  name: string;
  tagline: string;
  popular?: boolean;
  bestValue?: boolean;
  bonus?: string;
  terms: string;
}

export interface AttachedFile {
  name: string;
  type: string;
  size: number;
  dataUrl: string; // base64 representation
}

export interface GenerationHistoryItem {
  id: string;
  timestamp: number;
  category: CategoryId;
  prompt: string;
  result: string;
  tone: ToneId;
  assistantId?: string;
  assistantName?: string;
  isBookmarked?: boolean;
  latencyMs?: number;
  estimatedTokens?: number;
  feedback?: 'like' | 'dislike';
  fileAttachment?: {
    name: string;
    type: string;
  };
}

export interface SecurityViolation {
  isSecurityViolation: boolean;
  threatType: 'hacking' | 'phishing' | 'spam';
  threatName?: string;
  title: string;
  warningMessage: string;
  warningMessageEn?: string;
  safetyAdvice?: string;
  timestamp: number;
}

export interface AnalyticsMetrics {
  totalGenerations: number;
  successRate: number;
  averageLatencyMs: number;
  totalTokensEstimated: number;
  dau: number;
  mau: number;
  categoryDistribution: Record<string, number>;
  featureUsage: {
    voiceInputs: number;
    fileUploads: number;
    copies: number;
    exports: number;
    bookmarks: number;
    likes: number;
    dislikes: number;
  };
  security?: {
    threatsBlocked: number;
    breakdown: {
      hacking: number;
      phishing: number;
      spam: number;
    };
    securityUptime: string;
    firewallStatus: string;
  };
  recentEvents: Array<{
    id: string;
    type: string;
    name: string;
    timestamp: number;
  }>;
}

export type DiagnosticSeverity = 'healthy' | 'info' | 'warning' | 'critical';

export interface DiagnosticIssue {
  id: string;
  category: 'gemini_api' | 'network' | 'recharge' | 'security' | 'storage' | 'client';
  severity: DiagnosticSeverity;
  title: string;
  detectedProblem: string;
  detectedProblemEn?: string;
  rootCause: string;
  timestamp: number;
  autoFixAvailable?: boolean;
  stepByStepInstructions: string[];
  docUrl?: string;
  resolved?: boolean;
}

export interface SystemHealthReport {
  timestamp: number;
  status: 'healthy' | 'degraded' | 'critical';
  uptimeSeconds: number;
  memoryUsageMb: number;
  checks: {
    geminiApi: {
      status: 'healthy' | 'degraded' | 'critical';
      hasKey: boolean;
      latencyMs?: number;
      message: string;
      details?: string;
    };
    securityEngine: {
      status: 'healthy' | 'degraded';
      blockedThreatsCount: number;
      message: string;
    };
    assistantsStore: {
      status: 'healthy' | 'degraded';
      totalCount: number;
      message: string;
    };
    rechargeGateway: {
      status: 'healthy' | 'degraded';
      mode: string;
      message: string;
    };
  };
  activeIssues: DiagnosticIssue[];
  resolvedIssuesCount: number;
}
