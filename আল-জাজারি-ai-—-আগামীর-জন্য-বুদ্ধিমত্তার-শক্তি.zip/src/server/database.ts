import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface TierConfig {
  id: string;
  name: string;
  price: number;
  sessionQuota: number;
  credits: number;
  durationDays: number;
  perks: string[];
  tagline: string;
}

/**
 * 5 Rich Package Tiers Configuration:
 * ৳১০ (স্টার্টার এক্সেস) — ১০টি এআই সেশন | ৩ দিন মেয়াদ
 * ৳৫০ (স্ট্যান্ডার্ড প্রফেশনাল) — ৫০টি এআই সেশন | ৩০ দিন মেয়াদ (জনপ্রিয়)
 * ৳১০০ (বিজনেস প্রিমিয়াম) — ১২০টি এআই সেশন | ৬০ দিন মেয়াদ | প্রায়োরিটি সাপোর্ট
 * ৳১৫০ (অ্যাডভান্সড এআই প্লাস) — ২০০টি এআই সেশন | ৯০ দিন মেয়াদ | কাস্টম এআই এক্সেস
 * ৳২০০ (আলটিমেট এন্টারপ্রাইজ) — অসীমিত/হাই-কোটা এআই সেশন | ১৮০ দিন মেয়াদ | ফ্রিল্যান্সার ও টিম
 */
export function getTierConfig(packageIdOrAmount?: string | number): TierConfig {
  const num = typeof packageIdOrAmount === 'number'
    ? packageIdOrAmount
    : Number(packageIdOrAmount) || 0;
  const idStr = String(packageIdOrAmount || '');

  if (idStr === 'pack_200' || num >= 200) {
    return {
      id: 'pack_200',
      name: 'আলটিমেট এন্টারপ্রাইজ',
      price: 200,
      sessionQuota: 1000,
      credits: 2000,
      durationDays: 180,
      perks: ['অসীমিত / হাই-কোটা এআই সেশন', '১৮০ দিন মেয়াদ', 'ফ্রিল্যান্সার ও টিম ব্যবহারের জন্য সম্পূর্ণ ক্লাউড সাপোর্ট', 'সর্বোচ্চ অগ্রাধিকার'],
      tagline: 'ফ্রিল্যান্সার ও টিম ব্যবহারের জন্য সম্পূর্ণ ক্লাউড সাপোর্ট',
    };
  }
  if (idStr === 'pack_150' || num >= 150) {
    return {
      id: 'pack_150',
      name: 'অ্যাডভান্সড এআই প্লাস',
      price: 150,
      sessionQuota: 200,
      credits: 1000,
      durationDays: 90,
      perks: ['২০০টি এআই সেশন কোটা', '৯০ দিন মেয়াদ', 'কাস্টম এআই অ্যাসিস্ট্যান্ট এক্সেস', 'উচ্চগতির ডেডিকেটেড মডেল'],
      tagline: 'কাস্টম এআই অ্যাসিস্ট্যান্ট এক্সেস ও হাই-স্পিড',
    };
  }
  if (idStr === 'pack_100' || num >= 100) {
    return {
      id: 'pack_100',
      name: 'বিজনেস প্রিমিয়াম',
      price: 100,
      sessionQuota: 120,
      credits: 600,
      durationDays: 60,
      perks: ['১২০টি এআই সেশন কোটা', '৬০ দিন মেয়াদ', 'দ্রুত রেসপন্স ও অগ্রাধিকার সাপোর্ট', 'ক্লায়েন্ট প্রপোজাল ড্রাফটিং'],
      tagline: 'দ্রুত রেসপন্স ও অগ্রাধিকার সাপোর্ট',
    };
  }
  if (idStr === 'pack_50' || num >= 50) {
    return {
      id: 'pack_50',
      name: 'স্ট্যান্ডার্ড প্রফেশনাল',
      price: 50,
      sessionQuota: 50,
      credits: 250,
      durationDays: 30,
      perks: ['৫০টি এআই সেশন কোটা', '৩০ দিন মেয়াদ', 'রেজ্যুমে, রিসার্চ ও প্রাতিষ্ঠানিক কাজ', 'সর্বাধিক জনপ্রিয়'],
      tagline: 'নিয়মিত পেশাদার কাজের জন্য সর্বাধিক জনপ্রিয়',
    };
  }
  // Default: ৳১০
  return {
    id: 'pack_10',
    name: 'স্টার্টার এক্সেস',
    price: 10,
    sessionQuota: 10,
    credits: 50,
    durationDays: 3,
    perks: ['১০টি এআই সেশন কোটা', '৩ দিন মেয়াদ', 'স্টুডেন্ট ও দ্রুত টেস্ট ড্রাফট'],
    tagline: 'ট্রায়াল ও শিক্ষার্থীদের জন্য উপযুক্ত',
  };
}

export interface TransactionRecord {
  tran_id: string;
  val_id?: string;
  bank_tran_id?: string;
  amount: number;
  currency: string;
  card_type?: string;
  packageId: string;
  packageName: string;
  sessionQuota: number;
  creditsGranted: number;
  durationDays: number;
  expiresAt?: number;
  userStatus: 'PRO সক্রিয়' | 'সাধারণ';
  status: 'VALID' | 'FAILED' | 'CANCELLED' | 'PENDING';
  userId?: string;
  createdAt: number;
  updatedAt: number;
  customer: {
    name: string;
    email: string;
    phone: string;
    address?: string;
    city?: string;
  };
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: 'PRO সক্রিয়' | 'সাধারণ';
  credits: number;
  sessionQuota: number;
  packageId?: string;
  packageName?: string;
  planDurationDays?: number;
  planExpiresAt?: number;
  perks?: string[];
  lastTransactionId?: string;
  updatedAt: number;
}

interface DatabaseData {
  userProfile: UserProfile;
  transactions: TransactionRecord[];
}

const DB_FILE_PATH = path.resolve(__dirname, '../../data/database.json');

// Default initial state with ৳৫০ standard tier
const initialTier = getTierConfig(50);
const defaultDbData: DatabaseData = {
  userProfile: {
    id: 'usr_default_jazari',
    name: 'Customer Name',
    email: 'customer@example.com',
    phone: '01711111111',
    status: 'PRO সক্রিয়',
    credits: 500,
    sessionQuota: 50,
    packageId: initialTier.id,
    packageName: initialTier.name,
    planDurationDays: initialTier.durationDays,
    planExpiresAt: Date.now() + initialTier.durationDays * 24 * 60 * 60 * 1000,
    perks: initialTier.perks,
    lastTransactionId: 'TXN_INIT_1792414428',
    updatedAt: Date.now(),
  },
  transactions: [
    {
      tran_id: 'TXN_1792414428',
      val_id: 'VAL_INIT_987654321',
      bank_tran_id: 'BANK_INIT_554433',
      amount: 100.0,
      currency: 'BDT',
      card_type: 'MFS-bKash-Sandbox',
      packageId: 'pack_100',
      packageName: 'বিজনেস প্রিমিয়াম',
      sessionQuota: 120,
      creditsGranted: 600,
      durationDays: 60,
      expiresAt: Date.now() + 60 * 24 * 60 * 60 * 1000,
      userStatus: 'PRO সক্রিয়',
      status: 'VALID',
      userId: 'usr_default_jazari',
      createdAt: Date.now() - 3600000 * 24,
      updatedAt: Date.now() - 3600000 * 24,
      customer: {
        name: 'Customer Name',
        email: 'customer@example.com',
        phone: '01711111111',
        address: 'Dhaka',
        city: 'Dhaka',
      },
    },
  ],
};

export interface UpdateSuccessResult {
  isAlreadyProcessed: boolean;
  transaction: TransactionRecord;
  userProfile: UserProfile;
}

class DatabaseService {
  private data: DatabaseData = defaultDbData;
  private supabase: SupabaseClient | null = null;
  public isSupabaseConnected = false;

  constructor() {
    this.loadFromDisk();
    this.initSupabase();
  }

  private initSupabase() {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

    if (supabaseUrl && supabaseKey && supabaseUrl.startsWith('https://')) {
      try {
        this.supabase = createClient(supabaseUrl, supabaseKey);
        this.isSupabaseConnected = true;
        console.log('✅ Supabase Client initialized for payment & user sync');
      } catch (err) {
        console.warn('⚠️ Supabase initialization skipped:', err);
      }
    } else {
      console.log('ℹ️ Supabase credentials not set; using authoritative local DB engine for payments & PRO status.');
    }
  }

  private loadFromDisk() {
    try {
      const dir = path.dirname(DB_FILE_PATH);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      if (fs.existsSync(DB_FILE_PATH)) {
        const raw = fs.readFileSync(DB_FILE_PATH, 'utf-8');
        this.data = JSON.parse(raw);
      } else {
        this.saveToDisk();
      }
    } catch (err) {
      console.error('Error loading database file, falling back to memory:', err);
    }
  }

  private saveToDisk() {
    try {
      const dir = path.dirname(DB_FILE_PATH);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DB_FILE_PATH, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error saving database to file:', err);
    }
  }

  public getUserProfile(): UserProfile {
    return this.data.userProfile;
  }

  public getTransactions(): TransactionRecord[] {
    return this.data.transactions;
  }

  public getTransactionById(tranId: string): TransactionRecord | undefined {
    return this.data.transactions.find((t) => t.tran_id === tranId);
  }

  public savePendingTransaction(transaction: TransactionRecord): void {
    const index = this.data.transactions.findIndex((t) => t.tran_id === transaction.tran_id);
    if (index >= 0) {
      this.data.transactions[index] = transaction;
    } else {
      this.data.transactions.unshift(transaction);
    }
    this.saveToDisk();
  }

  /**
   * Idempotent Payment Success Update:
   * - If already VALID, skips duplicate increments to prevent multi-activations.
   * - Assigns accurate AI session quota, perks, and expiration duration based on tier.
   * - Persists immediately to local DB and syncs to Supabase transactions and user_profiles tables.
   */
  public async updatePaymentSuccess(
    tranId: string,
    valId?: string,
    cardType?: string,
    bankTranId?: string,
    customAmount?: number,
    customUserId?: string
  ): Promise<UpdateSuccessResult> {
    let tx = this.data.transactions.find((t) => t.tran_id === tranId);

    // IDEMPOTENCY CHECK: If transaction is already VALID, return early without re-granting perks
    if (tx && tx.status === 'VALID') {
      console.log(`ℹ️ [DB] Transaction ${tranId} is already VALID. Idempotently acknowledging.`);
      return {
        isAlreadyProcessed: true,
        transaction: tx,
        userProfile: this.data.userProfile,
      };
    }

    const effectiveAmount = customAmount || (tx ? tx.amount : 50);
    const tier = getTierConfig(tx?.packageId || effectiveAmount);
    const expiresAt = Date.now() + tier.durationDays * 24 * 60 * 60 * 1000;
    const resolvedUserId = customUserId || tx?.userId || this.data.userProfile.id || 'usr_default_jazari';

    if (!tx) {
      // Create if record was not preregistered
      tx = {
        tran_id: tranId,
        val_id: valId || `VAL_${Date.now()}`,
        bank_tran_id: bankTranId || `BNK_${Date.now()}`,
        amount: tier.price,
        currency: 'BDT',
        card_type: cardType || 'SSLCommerz Sandbox',
        packageId: tier.id,
        packageName: tier.name,
        sessionQuota: tier.sessionQuota,
        creditsGranted: tier.credits,
        durationDays: tier.durationDays,
        expiresAt,
        userStatus: 'PRO সক্রিয়',
        status: 'VALID',
        userId: resolvedUserId,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        customer: {
          name: this.data.userProfile.name,
          email: this.data.userProfile.email,
          phone: this.data.userProfile.phone,
        },
      };
      this.data.transactions.unshift(tx);
    } else {
      tx.status = 'VALID';
      tx.val_id = valId || tx.val_id || `VAL_${Date.now()}`;
      tx.card_type = cardType || tx.card_type || 'SSLCommerz Sandbox';
      tx.bank_tran_id = bankTranId || tx.bank_tran_id || `BNK_${Date.now()}`;
      tx.packageId = tier.id;
      tx.packageName = tier.name;
      tx.sessionQuota = tier.sessionQuota;
      tx.creditsGranted = tier.credits;
      tx.durationDays = tier.durationDays;
      tx.expiresAt = expiresAt;
      tx.userStatus = 'PRO সক্রিয়';
      tx.userId = resolvedUserId;
      tx.updatedAt = Date.now();
    }

    // Update user profile status to 'PRO সক্রিয়', assign quota and plan expiration
    this.data.userProfile.status = 'PRO সক্রিয়';
    this.data.userProfile.lastTransactionId = tranId;
    this.data.userProfile.packageId = tier.id;
    this.data.userProfile.packageName = tier.name;
    this.data.userProfile.credits = (this.data.userProfile.credits || 0) + tier.credits;
    this.data.userProfile.sessionQuota = (this.data.userProfile.sessionQuota || 0) + tier.sessionQuota;
    this.data.userProfile.planDurationDays = tier.durationDays;
    this.data.userProfile.planExpiresAt = expiresAt;
    this.data.userProfile.perks = tier.perks;
    this.data.userProfile.updatedAt = Date.now();

    this.saveToDisk();

    // Async sync to Supabase if configured
    if (this.supabase && this.isSupabaseConnected) {
      try {
        await this.supabase.from('transactions').upsert({
          tran_id: tx.tran_id,
          val_id: tx.val_id,
          bank_tran_id: tx.bank_tran_id,
          amount: tx.amount,
          currency: tx.currency,
          card_type: tx.card_type,
          status: 'VALID',
          package_id: tier.id,
          package_name: tier.name,
          session_quota: tier.sessionQuota,
          duration_days: tier.durationDays,
          expires_at: new Date(expiresAt).toISOString(),
          user_id: resolvedUserId,
          user_status: 'PRO সক্রিয়',
          customer_name: tx.customer.name,
          customer_email: tx.customer.email,
          customer_phone: tx.customer.phone,
          created_at: new Date(tx.createdAt).toISOString(),
          updated_at: new Date(tx.updatedAt).toISOString(),
        });

        await this.supabase.from('user_profiles').upsert({
          id: resolvedUserId,
          name: this.data.userProfile.name,
          email: this.data.userProfile.email,
          phone: this.data.userProfile.phone,
          status: 'PRO সক্রিয়',
          last_transaction_id: tranId,
          package_id: tier.id,
          package_name: tier.name,
          session_quota: this.data.userProfile.sessionQuota,
          credits: this.data.userProfile.credits,
          plan_duration_days: tier.durationDays,
          plan_expires_at: new Date(expiresAt).toISOString(),
          perks: tier.perks,
          updated_at: new Date().toISOString(),
        });

        console.log(`✅ [Supabase] Successfully synced transaction ${tranId} and user status 'PRO সক্রিয়' with tier ${tier.name} (Quota: ${tier.sessionQuota}, Duration: ${tier.durationDays}d)`);
      } catch (err) {
        console.error('Failed to sync payment status to Supabase tables:', err);
      }
    }

    return {
      isAlreadyProcessed: false,
      transaction: tx,
      userProfile: this.data.userProfile,
    };
  }

  public updatePaymentFailure(tranId: string): TransactionRecord | null {
    const tx = this.data.transactions.find((t) => t.tran_id === tranId);
    if (tx) {
      tx.status = 'FAILED';
      tx.updatedAt = Date.now();
      this.saveToDisk();
      return tx;
    }
    return null;
  }

  public updatePaymentCancel(tranId: string): TransactionRecord | null {
    const tx = this.data.transactions.find((t) => t.tran_id === tranId);
    if (tx) {
      tx.status = 'CANCELLED';
      tx.updatedAt = Date.now();
      this.saveToDisk();
      return tx;
    }
    return null;
  }
}

export const dbService = new DatabaseService();
