import { CategoryInfo, ToneInfo, RechargePack, AssistantInfo } from '../types';

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'student',
    number: '০১',
    name: 'পড়াশোনা ও গবেষণা',
    subtitle: 'অ্যাসাইনমেন্ট ও জটিল বিষয় বিশ্লেষণ',
    icon: '🎓',
    badge: 'STUDENTS',
    badgeColor: 'bg-rose-500 text-white',
    placeholder: 'আপনার গবেষণার বিষয়, অ্যাসাইনমেন্টের টপিক বা যেকোনো অ্যাকাডেমিক প্রশ্ন লিখুন...',
    purpose: 'অ্যাকাডেমিক প্রশ্ন বিশ্লেষণ, কাঠামোগত নোট প্রস্তুতি এবং গবেষণামূলক সহায়তা।',
    quickPrompts: [
      'কোয়ান্টাম কম্পিউটিংয়ের মৌলিক নীতিগুলো সহজ ভাষায় ব্যাখ্যা করুন',
      'মেশিন লার্নিং অ্যালগরিদমের তুলনামূলক সারাংশ তৈরি করুন',
      'বিশ্ব অর্থনীতিতে অটোমেশনের প্রভাব নিয়ে গবেষণার আউটলাইন',
      'আইটি প্রজেক্ট ম্যানেজমেন্টের ধাপসমূহের কাঠামোগত গাইড'
    ],
  },
  {
    id: 'career',
    number: '০২',
    name: 'সিভি ও ক্যারিয়ার প্রস্তুতি',
    subtitle: 'কভার লেটার ও ইন্টারভিউ গাইড',
    icon: '💼',
    badge: 'JOB SEEKERS',
    badgeColor: 'bg-indigo-600 text-white',
    placeholder: 'পদের নাম, আপনার পূর্ব অভিজ্ঞতা অথবা ইন্টারভিউ প্রশ্নের বিষয়বস্তু লিখুন...',
    purpose: 'পেশাদার সিভি বুলেট পয়েন্ট, আধুনিক কভার লেটার ও মক ইন্টারভিউ গাইডলাইন।',
    quickPrompts: [
      'সফটওয়্যার ইঞ্জিনিয়ারিং পদের জন্য পেশাদার কভার লেটার তৈরি করুন',
      'সিভিতে ব্যবহারের উপযোগী শক্তিশালী ইমপ্যাক্ট বুলেট পয়েন্ট',
      'প্রজেক্ট ম্যানেজার পদের বহুল জিজ্ঞাসিত ইন্টারভিউ প্রশ্নোত্তর',
      'লিংকডইন সামারি ও ক্যারিয়ার অবজেক্টিভ খসড়া'
    ],
  },
  {
    id: 'freelance',
    number: '০৩',
    name: 'ফ্রিল্যান্সিং ও ক্লায়েন্ট বার্তা',
    subtitle: 'আন্তর্জাতিক প্রপোজাল ও গিগ তৈরি',
    icon: '💻',
    badge: 'FREELANCERS',
    badgeColor: 'bg-teal-500 text-white',
    placeholder: 'ক্লায়েন্টের কাজের বিবরণ (Job Description) বা প্রজেক্টের রিকোয়ারমেন্ট দিন...',
    purpose: 'Upwork, Fiverr বা সরাসরি ক্লায়েন্টদের জন্য পেশাদার প্রস্তাবনা এবং ফলো-আপ খসড়া।',
    quickPrompts: [
      'Upwork কাজের বিবরণের জন্য উচ্চ রূপান্তরযোগ্য প্রপোজাল লিখুন',
      'ক্লায়েন্টকে প্রজেক্ট মাইলস্টোন ও কাজের পরিধি ব্যাখ্যা করে ইমেইল',
      'ওয়েব ডেভেলপমেন্ট কাজের জন্য বিস্তারিত প্রজেক্ট এস্টিমেট',
      'পেমেন্ট রিলিজ ও কাজ সফলভাবে সম্পন্ন করার ফলো-আপ নোট'
    ],
  },
  {
    id: 'creator',
    number: '০৪',
    name: 'কনটেন্ট ও ডিজিটাল মিডিয়া',
    subtitle: 'আকর্ষণীয় স্ক্রিপ্ট ও ব্র্যান্ড প্রচার',
    icon: '📸',
    badge: 'CREATORS',
    badgeColor: 'bg-amber-500 text-white',
    placeholder: 'আপনার কনটেন্টের মূল ভাবনা, উদ্দিষ্ট দর্শক বা ব্র্যান্ড ক্যাম্পেইন লিখুন...',
    purpose: 'তথ্যবহুল নিবন্ধ, শিক্ষামূলক ভিডিও স্ক্রিপ্ট এবং ব্র্যান্ড সোশ্যাল মিডিয়া প্রচার।',
    quickPrompts: [
      'এআই প্রযুক্তির ভবিষ্যৎ নিয়ে একটি প্রাতিষ্ঠানিক প্রবন্ধের কাঠামো',
      'ইউটিউব শিক্ষামূলক ভিডিওর জন্য দৃশ্যভিত্তিক স্ক্রিপ্ট ও হুক',
      'নতুন ডিজিটাল সেবার জন্য উচ্চ কনভার্শন বিজ্ঞাপনী কপি',
      'পেশাদার নিউজলেটার ও প্রযুক্তি বিষয়ক সারসংক্ষেপ'
    ],
  },
];

export const TONES: ToneInfo[] = [
  {
    id: 'formal',
    name: 'প্রাতিষ্ঠানিক ও ফরমাল',
    description: 'অফিসিয়াল চিঠি ও প্রাতিষ্ঠানিক যোগাযোগের জন্য উপযুক্ত',
    badge: 'Formal',
  },
  {
    id: 'academic',
    name: 'অ্যাকাডেমিক ও গভীর',
    description: 'গবেষণা ও বিশ্লেষণধর্মী শিক্ষার জন্য সুনির্দিষ্ট',
    badge: 'Academic',
  },
  {
    id: 'business',
    name: 'ব্যবসায়িক ও ক্লায়েন্ট',
    description: 'ক্লায়েন্ট প্রস্তাবনা ও সেলস কনটেন্টের জন্য কার্যকর',
    badge: 'Business',
  },
  {
    id: 'concise',
    name: 'সহজ ও সরাসরি',
    description: 'সংক্ষিপ্ত, স্পষ্ট ও সহজে বোধগম্য উপস্থাপন',
    badge: 'Concise',
  },
];

export const DEFAULT_ASSISTANTS: AssistantInfo[] = [
  {
    id: 'ast_research',
    name: 'গবেষণা ও থিসিস বিশেষজ্ঞ',
    role: 'Academic Researcher',
    description: 'উচ্চতর গবেষণা, থিসিস আর্কিটেকচার, সাহিত্য পর্যালোচনা ও জার্নাল পেপারের রূপরেখা বিশ্লেষক।',
    icon: '🔬',
    category: 'student',
    tone: 'academic',
    systemPrompt: `You are an elite Academic Research Assistant on the Al-Jazari AI platform.
You specialize in university-level research, thesis structuring, methodology verification, literature review, and factual synthesis.
Provide structured academic frameworks, citation guidance, and objective, high-rigor analysis in clear Bengali with English terminology where necessary.`,
    isCustom: false,
    usageCount: 428,
  },
  {
    id: 'ast_proposal',
    name: 'ফ্রিল্যান্সিং প্রপোজাল মাস্টার',
    role: 'Proposal Specialist',
    description: 'Upwork, Fiverr ও ডিরেক্ট ক্লায়েন্টদের জন্য সর্বোচ্চ কনভার্শনযোগ্য কাস্টম বিড ও ফলো-আপ রাইটার।',
    icon: '🚀',
    category: 'freelance',
    tone: 'business',
    systemPrompt: `You are the Freelancing Proposal Master on the Al-Jazari AI platform.
You craft high-converting, professional, tailored Upwork and Fiverr job proposals and client emails.
Always identify the client's core bottleneck in the first sentence, state precise deliverables with timeline, highlight risk mitigation, and close with a low-friction call to action.`,
    isCustom: false,
    usageCount: 652,
  },
  {
    id: 'ast_career',
    name: 'ক্যারিয়ার ও সিভি আর্কিটেক্ট',
    role: 'Career Coach',
    description: 'ATS-বান্ধব রেজ্যুমে, শক্তিশালী ইমপ্যাক্ট মেট্রিক্স বুলেটস ও এক্সিকিউটিভ ইন্টারভিউ প্রস্তুতি।',
    icon: '👔',
    category: 'career',
    tone: 'formal',
    systemPrompt: `You are an Executive Career Coach & Resume Architect on the Al-Jazari AI platform.
You specialize in ATS-friendly resume points, high-impact STAR methodology accomplishments, tailored cover letters, and mock behavioral interview Q&As. Focus on quantified results and leadership indicators.`,
    isCustom: false,
    usageCount: 319,
  },
  {
    id: 'ast_copywriter',
    name: 'ডিজিটাল ব্র্যান্ড কপিরাইটার',
    role: 'Brand Copywriter',
    description: 'সোশ্যাল মিডিয়া ক্যাম্পেইন, আকর্ষণীয় ভিডিও স্ক্রিপ্ট ও উচ্চ রূপান্তরমুখী ব্র্যান্ড বিজ্ঞাপন।',
    icon: '✍️',
    category: 'creator',
    tone: 'concise',
    systemPrompt: `You are a Senior Digital Brand Copywriter on the Al-Jazari AI platform.
You craft viral yet brand-safe hooks, YouTube scripts with visual cue markers, engaging LinkedIn thought-leadership posts, and high-conversion ad copies. Make every word purposeful, punchy, and structured.`,
    isCustom: false,
    usageCount: 512,
  },
  {
    id: 'ast_tech',
    name: 'সফটওয়্যার ও টেকনিক্যাল এক্সপার্ট',
    role: 'Tech Architect',
    description: 'কোডিং সমাধান, আর্কিটেকচার ডিজাইন, অ্যালগরিদম ব্যাখ্যা ও টেকনিক্যাল ডকুমেন্টেশন।',
    icon: '💻',
    category: 'student',
    tone: 'formal',
    systemPrompt: `You are a Principal Software Architect on the Al-Jazari AI platform.
You write clean, production-grade code, explain complex algorithms simply, troubleshoot errors, and design scalable system architectures with clean markdown formatting.`,
    isCustom: false,
    usageCount: 384,
  },
];

export const RECHARGE_PACKS: RechargePack[] = [
  {
    id: 'pack_10',
    price: 10,
    credits: 50,
    quotaLabel: '১০টি এআই সেশন',
    name: 'স্টার্টার এক্সেস',
    tagline: 'ট্রায়াল ও শিক্ষার্থীদের জন্য উপযুক্ত',
    bonus: '১০টি সেশন কোটা',
    terms: 'মেয়াদ: ৩ দিন • স্টুডেন্ট ও দ্রুত টেস্ট ড্রাফট',
  },
  {
    id: 'pack_50',
    price: 50,
    credits: 250,
    quotaLabel: '৫০টি এআই সেশন',
    name: 'স্ট্যান্ডার্ড প্রফেশনাল',
    tagline: 'নিয়মিত পেশাদার কাজের জন্য সর্বাধিক জনপ্রিয়',
    popular: true,
    bonus: '৫০টি সেশন কোটা',
    terms: 'মেয়াদ: ৩০ দিন • রেজ্যুমে, রিসার্চ ও প্রাতিষ্ঠানিক কাজ',
  },
  {
    id: 'pack_100',
    price: 100,
    credits: 600,
    quotaLabel: '১২০টি এআই সেশন',
    name: 'বিজনেস প্রিমিয়াম',
    tagline: 'দ্রুত রেসপন্স ও অগ্রাধিকার সাপোর্ট',
    bestValue: true,
    bonus: '১২০টি সেশন কোটা',
    terms: 'মেয়াদ: ৬০ দিন • ক্লায়েন্ট প্রপোজাল ও বিজনেস ড্রাফটিং',
  },
  {
    id: 'pack_150',
    price: 150,
    credits: 1000,
    quotaLabel: '২০০টি এআই সেশন',
    name: 'অ্যাডভান্সড এআই প্লাস',
    tagline: 'কাস্টম এআই অ্যাসিস্ট্যান্ট এক্সেস ও হাই-স্পিড',
    bonus: '২০০টি সেশন কোটা',
    terms: 'মেয়াদ: ৯০ দিন • পার্সোনাল অ্যাসিস্ট্যান্ট ও ডেটা প্রসেসিং',
  },
  {
    id: 'pack_200',
    price: 200,
    credits: 2000,
    quotaLabel: 'অসীমিত / হাই-কোটা সেশন',
    name: 'আলটিমেট এন্টারপ্রাইজ',
    tagline: 'ফ্রিল্যান্সার ও টিম ব্যবহারের জন্য সম্পূর্ণ ক্লাউড সাপোর্ট',
    bonus: 'সীমাহীন প্রায়োরিটি কোটা',
    terms: 'মেয়াদ: ১৮০ দিন • মাল্টি-প্রজেক্ট ও এন্টারপ্রাইজ কোটা',
  },
];

export const LOADING_PUNCHLINES = [
  'প্রক্রিয়াকরণ চলছে...',
  'উপাত্ত বিশ্লেষণ ও ফলাফল প্রস্তুত করা হচ্ছে...',
  'যথাযথ মান যাচাই করে চূড়ান্ত ড্রাফট তৈরি হচ্ছে...',
];
