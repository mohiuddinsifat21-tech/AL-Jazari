import React from 'react';
import { Home, Bot, Activity, History, Settings } from 'lucide-react';
import { audio } from '../utils/audio';
import { AppTab } from '../types';

interface BottomNavProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  historyCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  historyCount,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/85 backdrop-blur-3xl border-t border-slate-200/80 max-w-md mx-auto w-full px-2 py-1.5 shadow-xl sm:rounded-b-[36px]">
      <div className="grid grid-cols-5 gap-0.5 items-center text-center">
        {/* 1. Workspace / Home */}
        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onSelectTab('workspace');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'workspace'
              ? 'text-blue-600 font-black'
              : 'text-slate-500 hover:text-slate-800 font-semibold'
          }`}
        >
          <div className={`p-1.5 rounded-xl transition ${activeTab === 'workspace' ? 'bg-blue-50 text-blue-600 shadow-sm' : ''}`}>
            <Home className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5">হোম</span>
        </button>

        {/* 2. My Assistants */}
        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onSelectTab('assistants');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'assistants'
              ? 'text-blue-600 font-black'
              : 'text-slate-500 hover:text-slate-800 font-semibold'
          }`}
        >
          <div className={`p-1.5 rounded-xl transition ${activeTab === 'assistants' ? 'bg-blue-50 text-blue-600 shadow-sm' : ''}`}>
            <Bot className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5">সহকারী</span>
        </button>

        {/* 3. Analytics & Security */}
        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onSelectTab('analytics');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'analytics'
              ? 'text-blue-600 font-black'
              : 'text-slate-500 hover:text-slate-800 font-semibold'
          }`}
        >
          <div className={`p-1.5 rounded-xl transition ${activeTab === 'analytics' ? 'bg-blue-50 text-blue-600 shadow-sm' : ''}`}>
            <Activity className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5">অ্যানালিটিক্স</span>
        </button>

        {/* 4. History & Bookmarks */}
        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onSelectTab('history');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`relative flex flex-col items-center justify-center py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'history'
              ? 'text-blue-600 font-black'
              : 'text-slate-500 hover:text-slate-800 font-semibold'
          }`}
        >
          <div className={`p-1.5 rounded-xl transition relative ${activeTab === 'history' ? 'bg-blue-50 text-blue-600 shadow-sm' : ''}`}>
            <History className="w-4 h-4" />
            {historyCount > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-blue-600 text-white text-[8px] font-black flex items-center justify-center shadow-md">
                {historyCount > 9 ? '9+' : historyCount}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-0.5">ইতিহাস</span>
        </button>

        {/* 5. Settings */}
        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onSelectTab('settings');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'settings'
              ? 'text-blue-600 font-black'
              : 'text-slate-500 hover:text-slate-800 font-semibold'
          }`}
        >
          <div className={`p-1.5 rounded-xl transition ${activeTab === 'settings' ? 'bg-blue-50 text-blue-600 shadow-sm' : ''}`}>
            <Settings className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5">সেটিংস</span>
        </button>
      </div>
    </nav>
  );
};
