import React from 'react';
import { CategoryId } from '../types';
import { CATEGORIES } from '../data/categories';
import { audio } from '../utils/audio';

interface CategoryCardsProps {
  selectedCategory: CategoryId;
  onSelectCategory: (id: CategoryId) => void;
  onSelectQuickPrompt: (prompt: string, categoryId: CategoryId) => void;
}

export const CategoryCards: React.FC<CategoryCardsProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <div className="mb-5 text-left">
      {/* Section Header with generous spacing */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shadow-[0_0_8px_rgba(37,99,235,0.4)]" />
          <h3 className="text-xs sm:text-sm font-black text-slate-900 uppercase tracking-wider">
            ১. কাজের ধরন নির্বাচন করুন:
          </h3>
        </div>
        <span className="text-[11px] text-slate-500 font-bold">
          যেকোনো একটি বেছে নিন
        </span>
      </div>

      {/* 2x2 Category Cards Grid (Styled exactly like the Minimal UI reference artwork) */}
      <div className="grid grid-cols-2 gap-3">
        {CATEGORIES.map((cat) => {
          const isSelected = cat.id === selectedCategory;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                audio.playTick();
                onSelectCategory(cat.id);
              }}
              className={`relative rounded-3xl p-4 text-left transition-all duration-200 cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'minimal-card-active ring-2 ring-blue-600'
                  : 'minimal-card hover:border-blue-300'
              }`}
            >
              {/* Top Row matching reference artwork: Left Number Pill + Right Glass Icon Pod */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black shadow-sm ${cat.badgeColor}`}>
                  {cat.number}
                </span>

                <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-slate-100 to-white border border-slate-200/80 flex items-center justify-center text-lg shrink-0 shadow-sm">
                  {cat.icon}
                </div>
              </div>

              {/* Title & Subtitle with high contrast and proper line height */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h4 className="text-xs sm:text-sm font-black text-slate-900 leading-snug">
                    {cat.name}
                  </h4>
                </div>
                <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed font-medium">
                  {cat.subtitle}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
