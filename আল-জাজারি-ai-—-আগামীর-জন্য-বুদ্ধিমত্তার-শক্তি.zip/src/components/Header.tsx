import React from 'react';
import { Volume2, VolumeX, Moon, Sun } from 'lucide-react';
import { audio } from '../utils/audio';
import { ThemeMode } from '../types';

interface HeaderProps {
  onOpenRecharge: () => void;
  onOpenHistory?: () => void;
  historyCount?: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  userStatus?: string;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenRecharge,
  soundEnabled,
  onToggleSound,
  theme,
  onToggleTheme,
  userStatus = 'PRO সক্রিয়',
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-2xl border-b border-white/80 dark:border-slate-800 w-full shadow-sm flex flex-col">
      {/* 
        LINE 1: INDEPENDENT TOP BRAND & APP TITLE
        App name sits completely independently on the top line
      */}
      <div className="px-4.5 pt-3 pb-2.5 flex items-center justify-between border-b border-slate-100 dark:border-slate-800/60">
        <div className="flex items-center gap-3">
          <div
            onClick={() => audio.playTick()}
            className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 p-1.5 shrink-0 cursor-pointer hover:scale-105 active:scale-95 transition-transform flex items-center justify-center shadow-md ring-2 ring-white/60 dark:ring-slate-700"
          >
            <img
              src="/icon.svg"
              alt="আল-জাজারি এআই"
              className="w-full h-full object-contain filter drop-shadow"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>

          <div className="text-left">
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-black tracking-tight text-slate-900 dark:text-white leading-none">
                আল-জাজারি এআই
              </h1>
              <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-blue-600 text-white font-black uppercase tracking-wider shadow-xs">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-1 leading-none">
              আগামীর জন্য বুদ্ধিমত্তার শক্তি • প্রফেশনাল এআই প্ল্যাটফর্ম
            </p>
          </div>
        </div>
      </div>

      {/* 
        LINE 2: SEPARATE UNCLUTTERED ROW WITH STATUS INDICATORS & GLOBAL TOGGLES
        flex with justify-between, zero diagnostic buttons
      */}
      <div className="px-4.5 py-2 flex items-center justify-between gap-2.5 bg-slate-50/70 dark:bg-slate-900/60">
        {/* Left: Active Service Status & Subscription Indicator */}
        <button
          onClick={() => {
            audio.playTick();
            onOpenRecharge();
          }}
          className="flex items-center gap-2 bg-white/95 dark:bg-slate-800/95 hover:bg-white px-3 py-1.5 rounded-full text-xs font-bold text-slate-800 dark:text-slate-200 transition cursor-pointer active:scale-95 border border-slate-200/90 dark:border-slate-700 shadow-xs"
          title="সার্ভিস স্ট্যাটাস ও প্যাকেজসমূহ"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <span className="text-[11px] font-bold">
            {userStatus === 'PRO সক্রিয়' ? 'সীমাহীন অ্যাক্সেস' : 'প্যাকেজ নির্বাচন'}
          </span>
          <span className="text-[9px] bg-blue-600 text-white px-1.5 py-0.2 rounded font-black shadow-xs">
            {userStatus === 'PRO সক্রিয়' ? 'PRO সক্রিয়' : 'BASIC'}
          </span>
        </button>

        {/* Right: Only Essential Global Toggles (Theme/Sun & Audio toggles) */}
        <div className="flex items-center gap-1.5">
          {/* Theme Mode Toggle */}
          <button
            onClick={() => {
              audio.playTick();
              onToggleTheme();
            }}
            className="p-1.5 rounded-full bg-white/95 dark:bg-slate-800/95 hover:bg-white text-slate-600 dark:text-slate-300 transition cursor-pointer border border-slate-200/90 dark:border-slate-700 shadow-xs active:scale-95"
            title={theme === 'dark' ? 'লাইট মোড চালু করুন' : 'ডার্ক মোড চালু করুন'}
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-600" />
            )}
          </button>

          {/* Audio Feedback Toggle */}
          <button
            onClick={() => {
              onToggleSound();
              audio.playTick();
            }}
            className="p-1.5 rounded-full bg-white/95 dark:bg-slate-800/95 hover:bg-white text-slate-600 dark:text-slate-300 transition cursor-pointer border border-slate-200/90 dark:border-slate-700 shadow-xs active:scale-95"
            title={soundEnabled ? 'শব্দ বন্ধ' : 'শব্দ চালু'}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
