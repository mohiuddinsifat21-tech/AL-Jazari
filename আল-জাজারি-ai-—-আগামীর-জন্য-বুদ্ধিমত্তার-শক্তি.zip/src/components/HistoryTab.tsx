import React, { useState } from 'react';
import { GenerationHistoryItem } from '../types';
import { audio } from '../utils/audio';
import {
  History,
  Bookmark,
  BookmarkCheck,
  Copy,
  Check,
  Trash2,
  Search,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface HistoryTabProps {
  history: GenerationHistoryItem[];
  onSelectHistoryItem: (item: GenerationHistoryItem) => void;
  onClearHistory: () => void;
  onToggleBookmark: (id: string) => void;
  onDeleteHistoryItem: (id: string) => void;
  onGoToWorkspace: () => void;
}

export const HistoryTab: React.FC<HistoryTabProps> = ({
  history,
  onSelectHistoryItem,
  onClearHistory,
  onToggleBookmark,
  onDeleteHistoryItem,
  onGoToWorkspace,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBookmarkOnly, setFilterBookmarkOnly] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = history.filter((item) => {
    if (filterBookmarkOnly && !item.isBookmarked) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.prompt.toLowerCase().includes(q) ||
      item.result.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q)
    );
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    audio.playTick();
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-4 text-left">
      {/* Header Banner */}
      <div className="p-5 rounded-3xl minimal-hero text-slate-800 relative overflow-hidden">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-purple-100/80 text-purple-800 text-[11px] font-bold">
              <History className="w-3.5 h-3.5 text-purple-600" />
              <span>ইতিহাস ও বুকমার্কস</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              সংরক্ষিত ফলাফল
            </h2>
            <p className="text-xs text-slate-600 font-medium max-w-sm">
              আপনার পূর্ববর্তী সকল প্রম্পট, বুকমার্ক ও ফলাফলের নিরাপদ ক্লাউড রেকর্ড।
            </p>
          </div>

          {history.length > 0 && (
            <button
              type="button"
              onClick={() => {
                audio.playTick();
                if (confirm('আপনি কি সমস্ত ইতিহাস মুছে ফেলতে চান?')) {
                  onClearHistory();
                }
              }}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 transition cursor-pointer border border-rose-200"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>সব মুছুন</span>
            </button>
          )}
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="p-3.5 rounded-2xl minimal-card space-y-2 border border-slate-200/80">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="প্রম্পট বা ফলাফল খুঁজুন…"
              className="w-full minimal-input rounded-xl pl-8 pr-3 py-2 text-xs font-medium focus:outline-none"
            />
          </div>

          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setFilterBookmarkOnly((prev) => !prev);
            }}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 border shrink-0 ${
              filterBookmarkOnly
                ? 'bg-amber-100 text-amber-900 border-amber-300 shadow-sm'
                : 'bg-white/80 text-slate-700 hover:bg-slate-100 border-slate-200'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-600" />
            <span>বুকমার্ক</span>
          </button>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium px-1">
          <span>মোট: {filtered.length}টি ফলাফল পাওয়া গেছে</span>
          {filterBookmarkOnly && (
            <span className="text-amber-700 font-bold">ফিল্টার: কেবল বুকমার্ক</span>
          )}
        </div>
      </div>

      {/* History Items List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-8 rounded-3xl minimal-card text-center border-dashed border-slate-200">
            <Sparkles className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-700 mb-1">
              {filterBookmarkOnly ? 'কোনো বুকমার্ক সংরক্ষিত নেই' : 'কোনো ইতিহাস পাওয়া যায়নি'}
            </h4>
            <p className="text-xs text-slate-500 mb-4 font-medium">
              ওয়ার্কস্পেস থেকে নতুন প্রম্পট পাঠিয়ে ফলাফল তৈরি করুন।
            </p>
            <button
              type="button"
              onClick={() => {
                audio.playTick();
                onGoToWorkspace();
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl minimal-btn-primary text-white text-xs font-bold shadow-md transition cursor-pointer"
            >
              <span>ওয়ার্কস্পেসে যান</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className="p-4 rounded-2xl minimal-card border border-slate-200/80 hover:border-blue-300 transition space-y-2.5 text-left"
            >
              {/* Top metadata row */}
              <div className="flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold border border-blue-200 text-[10px]">
                    {item.category === 'student' ? 'শিক্ষা ও গবেষণা' : item.category === 'career' ? 'পেশাগত প্রস্তুতি' : item.category === 'freelance' ? 'ফ্রিল্যান্সিং' : 'কনটেন্ট মিডিয়া'}
                  </span>
                  <span className="text-[10px] text-slate-500 font-medium">
                    {new Date(item.timestamp).toLocaleDateString('bn-BD', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                {/* Bookmark Toggle */}
                <button
                  type="button"
                  onClick={() => {
                    audio.playTick();
                    onToggleBookmark(item.id);
                  }}
                  className={`p-1.5 rounded-lg border transition cursor-pointer ${
                    item.isBookmarked
                      ? 'bg-amber-100 text-amber-700 border-amber-300'
                      : 'bg-white/80 text-slate-400 hover:text-amber-600 border-slate-200'
                  }`}
                  title={item.isBookmarked ? 'বুকমার্ক সরান' : 'বুকমার্ক করুন'}
                >
                  {item.isBookmarked ? (
                    <BookmarkCheck className="w-3.5 h-3.5" />
                  ) : (
                    <Bookmark className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>

              {/* Prompt Query */}
              <p className="text-xs font-bold text-slate-800 line-clamp-2">
                &ldquo;{item.prompt}&rdquo;
              </p>

              {/* Output Preview */}
              <div className="p-2.5 rounded-xl bg-slate-50 text-xs text-slate-700 font-mono line-clamp-3 border border-slate-100">
                {item.result}
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      audio.playTick();
                      onSelectHistoryItem(item);
                      onGoToWorkspace();
                    }}
                    className="text-blue-600 hover:underline font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <span>পুনরায় লোড করুন</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleCopy(item.id, item.result)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-slate-100 transition cursor-pointer"
                    title="কপি করুন"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      audio.playTick();
                      onDeleteHistoryItem(item.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
