import React, { useState, useEffect } from 'react';
import { ArrowRight, Clock, Sparkles, BookOpen, Briefcase } from 'lucide-react';
import { audio } from '../utils/audio';

interface AdItem {
  id: string;
  badge: string;
  badgeColor: string;
  title: string;
  subtitle: string;
  validity: string;
  ctaText: string;
  type: 'recharge' | 'feature';
  icon: React.ReactNode;
}

const ADS: AdItem[] = [
  {
    id: 'ad_1',
    badge: 'পেশাদার সুবিধা',
    badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    title: 'প্রিমিয়াম এআই প্যাকেজে বর্ধিত কর্মক্ষমতা',
    subtitle: 'নিয়মিত ব্যবহারকারী ও পেশাজীবীদের জন্য সাশ্রয়ী প্যাকেজ ও নিরবচ্ছিন্ন ক্লাউড সেবা।',
    validity: 'প্যাকেজের মেয়াদ: ৯০ দিন পর্যন্ত',
    ctaText: 'প্যাকেজ দেখুন',
    type: 'recharge',
    icon: <Sparkles className="w-4 h-4 text-indigo-600" />,
  },
  {
    id: 'ad_2',
    badge: 'শিক্ষা ও গবেষণা',
    badgeColor: 'bg-rose-50 text-rose-700 border-rose-200',
    title: 'গবেষণামূলক প্রবন্ধ ও জটিল বিষয় সহজীকরণ',
    subtitle: 'উচ্চতর পাঠ্যক্রম ও থিসিসের জন্য নির্ভুল তথ্য কাঠামো ও বিশ্লেষণ সেবা।',
    validity: '২৪/৭ ক্লাউড এআই অ্যাক্সেস',
    ctaText: 'টুল ব্যবহার করুন',
    type: 'feature',
    icon: <BookOpen className="w-4 h-4 text-rose-600" />,
  },
  {
    id: 'ad_3',
    badge: 'ফ্রিল্যান্সিং',
    badgeColor: 'bg-teal-50 text-teal-700 border-teal-200',
    title: 'আন্তর্জাতিক ক্লায়েন্ট বার্তা ও প্রপোজাল',
    subtitle: 'Upwork ও Fiverr কাজের বিবরণের জন্য পেশাদার ও রূপান্তরমুখী প্রস্তাবনা তৈরি।',
    validity: 'শতভাগ প্রাতিষ্ঠানিক ফরম্যাট',
    ctaText: 'প্রস্তাবনা লিখুন',
    type: 'feature',
    icon: <Briefcase className="w-4 h-4 text-teal-600" />,
  },
];

interface AdBannerProps {
  onOpenRecharge: () => void;
  onSelectPrompt?: (prompt: string, category: 'student' | 'career' | 'freelance' | 'creator') => void;
}

export const AdBanner: React.FC<AdBannerProps> = ({ onOpenRecharge, onSelectPrompt }) => {
  const [currentIdx, setCurrentIdx] = useState(0);

  // Auto slide every 6 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIdx((prev) => (prev + 1) % ADS.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const currentAd = ADS[currentIdx];

  const handleAction = () => {
    audio.playTick();
    if (currentAd.type === 'recharge') {
      onOpenRecharge();
    } else if (currentAd.id === 'ad_2' && onSelectPrompt) {
      onSelectPrompt('মেশিন লার্নিং অ্যালগরিদমের তুলনামূলক সারাংশ তৈরি করুন', 'student');
      window.scrollTo({ top: 200, behavior: 'smooth' });
    } else if (currentAd.id === 'ad_3' && onSelectPrompt) {
      onSelectPrompt('Upwork কাজের বিবরণের জন্য উচ্চ রূপান্তরযোগ্য প্রপোজাল লিখুন', 'freelance');
      window.scrollTo({ top: 200, behavior: 'smooth' });
    }
  };

  return (
    <div className="my-6 text-left">
      {/* Minimal Clean Resource Card matching reference artwork */}
      <div className="relative overflow-hidden rounded-3xl minimal-card p-5 shadow-md transition-all duration-300">
        {/* Top Tag & Official Notice Label */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border shadow-sm ${currentAd.badgeColor}`}>
            {currentAd.icon}
            <span>{currentAd.badge}</span>
          </span>
          <span className="text-[10px] uppercase font-bold text-slate-500 minimal-pill px-2.5 py-0.5 rounded-full">
            ফিচার্ড রিসোর্স
          </span>
        </div>

        {/* Main Content */}
        <div className="space-y-1 mb-4">
          <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
            {currentAd.title}
          </h3>
          <p className="text-xs text-slate-600 font-medium leading-relaxed">
            {currentAd.subtitle}
          </p>
          <div className="flex items-center gap-1.5 text-[11px] text-blue-600 font-bold pt-1">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            <span>{currentAd.validity}</span>
          </div>
        </div>

        {/* Action Controls & Next Slide */}
        <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={() => setCurrentIdx((prev) => (prev + 1) % ADS.length)}
            className="text-xs font-bold text-slate-500 hover:text-slate-800 px-2 py-1 transition cursor-pointer underline"
          >
            পরবর্তী তথ্য
          </button>
          <button
            type="button"
            onClick={handleAction}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl minimal-btn-primary text-white font-black text-xs shadow-md transition hover:scale-105 active:scale-95 cursor-pointer"
          >
            <span>{currentAd.ctaText}</span>
            <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
          </button>
        </div>

        {/* Carousel Pagination Dots */}
        <div className="flex items-center justify-center gap-1.5 mt-3">
          {ADS.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                audio.playTick();
                setCurrentIdx(idx);
              }}
              className={`h-1.5 rounded-full transition-all cursor-pointer ${
                idx === currentIdx
                  ? 'w-6 bg-blue-600 shadow-sm'
                  : 'w-1.5 bg-slate-300 hover:bg-slate-400'
              }`}
              title={`স্লাইড ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
