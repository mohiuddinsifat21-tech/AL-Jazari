import React, { useState } from 'react';
import { AssistantInfo, CategoryId, ToneId } from '../types';
import { CATEGORIES, TONES } from '../data/categories';
import { audio } from '../utils/audio';
import {
  Bot,
  Plus,
  Trash2,
  Check,
  Sparkles,
  Zap,
  ArrowRight,
  ShieldCheck,
  BookOpen,
} from 'lucide-react';

interface AssistantsModuleProps {
  assistants: AssistantInfo[];
  activeAssistantId: string | null;
  onSelectAssistant: (assistant: AssistantInfo) => void;
  onCreateAssistant: (data: Omit<AssistantInfo, 'id'>) => Promise<void>;
  onDeleteAssistant: (id: string) => Promise<void>;
  onGoToWorkspace: () => void;
}

const EMOJI_OPTIONS = ['🤖', '💼', '🎓', '✍️', '🚀', '🔬', '💡', '🌐', '📊', '⚡'];

export const AssistantsModule: React.FC<AssistantsModuleProps> = ({
  assistants,
  activeAssistantId,
  onSelectAssistant,
  onCreateAssistant,
  onDeleteAssistant,
  onGoToWorkspace,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [description, setDescription] = useState('');
  const [icon, setIcon] = useState('🤖');
  const [category, setCategory] = useState<CategoryId>('student');
  const [tone, setTone] = useState<ToneId>('formal');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !systemPrompt.trim()) {
      setFormError('সহকারীর নাম এবং সিস্টেম প্রম্পট প্রদান করা আবশ্যক।');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);

    try {
      await onCreateAssistant({
        name: name.trim(),
        role: role.trim() || 'Custom AI Specialist',
        description: description.trim() || 'ব্যক্তিগত কাস্টম সহকারী',
        icon,
        category,
        tone,
        systemPrompt: systemPrompt.trim(),
        isCustom: true,
      });

      audio.playSuccess();
      setIsCreating(false);
      setName('');
      setRole('');
      setDescription('');
      setSystemPrompt('');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'সহকারী তৈরি করা যায়নি।';
      setFormError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4 text-left">
      {/* Header Banner */}
      <div className="p-5 rounded-3xl minimal-hero text-slate-800 relative overflow-hidden">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100/80 text-blue-800 text-[11px] font-bold">
              <Bot className="w-3.5 h-3.5 text-blue-600" />
              <span>পার্সোনাল এআই অ্যাসিস্ট্যান্টস (Phase 1)</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              আমার এআই সহকারী
            </h2>
            <p className="text-xs text-slate-600 font-medium max-w-sm">
              আপনার নির্দিষ্ট প্রজেক্ট ও কাজের জন্য তৈরি করুন ডেডিকেটেড এআই এজেন্ট।
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setIsCreating((prev) => !prev);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl minimal-btn-primary text-white text-xs sm:text-sm font-bold shadow-md transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{isCreating ? 'বাতিল করুন' : 'নতুন সহকারী তৈরি'}</span>
          </button>
        </div>
      </div>

      {/* Assistant Creation Modal / Drawer inside Section */}
      {isCreating && (
        <div className="p-5 rounded-3xl minimal-card border-2 border-blue-300 shadow-xl space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>কাস্টম এআই অ্যাসিস্ট্যান্ট কনফিগারেশন</span>
            </h3>
            <span className="text-xs text-slate-500 font-semibold">
              স্বয়ংক্রিয় সিস্টেম প্রম্পট
            </span>
          </div>

          {formError && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              {formError}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
            {/* Name & Role */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  সহকারীর নাম (Name):
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="যেমন: ফ্রিল্যান্সিং প্রপোজাল স্পেশালিস্ট"
                  className="w-full minimal-input rounded-xl p-2.5 text-xs font-medium focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  পদবি বা রোল (Role):
                </label>
                <input
                  type="text"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  placeholder="যেমন: Upwork Proposal Lead"
                  className="w-full minimal-input rounded-xl p-2.5 text-xs font-medium focus:outline-none"
                />
              </div>
            </div>

            {/* Icon Picker */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                আইকন প্রতীক (Icon):
              </label>
              <div className="flex items-center gap-2 flex-wrap">
                {EMOJI_OPTIONS.map((em) => (
                  <button
                    key={em}
                    type="button"
                    onClick={() => setIcon(em)}
                    className={`w-8 h-8 rounded-xl border text-sm flex items-center justify-center transition cursor-pointer ${
                      icon === em
                        ? 'bg-blue-100 border-blue-500 shadow-sm scale-110'
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    {em}
                  </button>
                ))}
              </div>
            </div>

            {/* Category & Tone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  মূল ক্যাটাগরি:
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as CategoryId)}
                  className="w-full minimal-input rounded-xl p-2.5 text-xs font-medium focus:outline-none"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  ডিফল্ট প্রকাশভঙ্গি:
                </label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value as ToneId)}
                  className="w-full minimal-input rounded-xl p-2.5 text-xs font-medium focus:outline-none"
                >
                  {TONES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                সংক্ষিপ্ত বিবরণ (Description):
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="সহকারী কী কাজে সহায়তা করবে তার ১ লাইনের বিবরণ"
                className="w-full minimal-input rounded-xl p-2.5 text-xs font-medium focus:outline-none"
              />
            </div>

            {/* System Prompt (Instructions) */}
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                সিস্টেম নির্দেশাবলী (System Instructions):
              </label>
              <textarea
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                rows={3}
                placeholder="এই এআই এজেন্টকে কীভাবে চিন্তা করতে হবে এবং কী ধরনের উত্তর দিতে হবে তা লিখুন..."
                className="w-full minimal-input rounded-xl p-3 text-xs font-medium focus:outline-none resize-none"
                required
              />
              <span className="text-[10px] text-slate-500 font-medium">
                * প্রতিটি অনুরোধের সময় এই নির্দেশাবলী স্বয়ংক্রিয়ভাবে জেমিনি এআই মডেলে পাঠানো হবে।
              </span>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-100 transition cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 rounded-xl minimal-btn-primary text-white font-bold transition shadow-md cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? 'সংরক্ষণ হচ্ছে…' : 'সহকারী সংরক্ষণ করুন'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* List of Assistants */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-blue-600" />
            <span>উপলব্ধ এআই সহকারী ({assistants.length}টি)</span>
          </span>
          <span className="text-[11px] text-slate-500 font-medium">
            ১-ক্লিকে সক্রিয় করুন
          </span>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {assistants.map((ast) => {
            const isActive = ast.id === activeAssistantId;

            return (
              <div
                key={ast.id}
                className={`p-4 rounded-2xl minimal-card transition relative border ${
                  isActive
                    ? 'border-blue-500 bg-blue-50/70 shadow-md'
                    : 'border-slate-200/80 hover:border-blue-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className="w-10 h-10 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-center text-xl shrink-0">
                      {ast.icon || '🤖'}
                    </div>

                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-black text-slate-900 leading-tight">
                          {ast.name}
                        </h4>
                        {ast.isCustom ? (
                          <span className="text-[10px] px-2 py-0.2 rounded-full bg-purple-100 text-purple-800 font-black border border-purple-200">
                            কাস্টম
                          </span>
                        ) : (
                          <span className="text-[10px] px-2 py-0.2 rounded-full bg-blue-100 text-blue-800 font-black border border-blue-200">
                            অফিসিয়াল
                          </span>
                        )}
                        {isActive && (
                          <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-black border border-emerald-300 flex items-center gap-1">
                            <Check className="w-3 h-3 stroke-[3]" />
                            <span>বর্তমানে সক্রিয়</span>
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 font-medium line-clamp-2">
                        {ast.description}
                      </p>

                      <div className="flex items-center gap-2 text-[10px] text-slate-500 pt-1 font-semibold flex-wrap">
                        <span>ভূমিকা: {ast.role}</span>
                        <span>•</span>
                        <span>ব্যবহার: {ast.usageCount || 0} বার</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        audio.playTick();
                        onSelectAssistant(ast);
                        onGoToWorkspace();
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer flex items-center gap-1 ${
                        isActive
                          ? 'bg-blue-600 text-white'
                          : 'minimal-btn-primary text-white hover:opacity-95'
                      }`}
                    >
                      <span>{isActive ? 'ব্যবহার করুন' : 'সক্রিয় করুন'}</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>

                    {ast.isCustom && (
                      <button
                        type="button"
                        onClick={() => {
                          audio.playTick();
                          if (confirm(`আপনি কি "${ast.name}" সহকারী মুছে ফেলতে চান?`)) {
                            onDeleteAssistant(ast.id);
                          }
                        }}
                        className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Information Banner */}
      <div className="p-4 rounded-3xl minimal-card text-left space-y-1.5 border border-slate-200/80">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
          <ShieldCheck className="w-4 h-4 text-blue-600" />
          <span>সহকারী সুরক্ষা ও মাল্টি-এজেন্ট ভবিষ্যৎ (Phase 2)</span>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed font-medium">
          আপনার কাস্টম অ্যাসিস্ট্যান্ট কনফিগারেশন সুরক্ষিত রাখা হয়। পরবর্তী আপডেটে একাধিক সহকারী একসাথে দলগতভাবে কাজ করার অটোমেশন (Company Mode) চালু হবে।
        </p>
      </div>
    </div>
  );
};
