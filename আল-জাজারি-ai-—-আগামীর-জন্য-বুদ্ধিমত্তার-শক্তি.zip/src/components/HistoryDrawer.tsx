import React from 'react';
import { GenerationHistoryItem } from '../types';
import { CATEGORIES } from '../data/categories';
import { X, Trash2, Clock, ArrowRight } from 'lucide-react';
import { audio } from '../utils/audio';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: GenerationHistoryItem[];
  onSelectHistoryItem: (item: GenerationHistoryItem) => void;
  onClearHistory: () => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  history,
  onSelectHistoryItem,
  onClearHistory,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/55 backdrop-blur-xl">
      <div className="w-full max-w-md bg-black/40 backdrop-blur-3xl border-l border-white/20 h-full flex flex-col shadow-2xl p-5 text-left">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/20">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl water-glass-pill text-white">
              <Clock className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-base font-bold text-white text-nature-shadow">কাজের ইতিহাস</h3>
              <p className="text-xs text-white/80 text-nature-shadow">সর্বমোট {history.length} টি ফলাফল সংরক্ষিত</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={() => {
                  if (confirm('আপনি কি পূর্ববর্তী সমস্ত ইতিহাস মুছে ফেলতে চান?')) {
                    onClearHistory();
                  }
                }}
                className="text-xs text-white/80 hover:text-white p-2 rounded-xl water-glass-pill transition"
                title="ইতিহাস পরিষ্কার করুন"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 p-2 rounded-xl water-glass-pill transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto py-4 space-y-2.5">
          {history.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-white/70">
              <Clock className="w-10 h-10 mb-2 opacity-50 text-white" />
              <p className="text-sm font-semibold text-white text-nature-shadow">এখনও কোনো ইতিহাস নেই</p>
              <p className="text-xs text-white/75 mt-1 text-nature-shadow">
                আপনার প্রস্তুতকৃত ফলাফলসমূহ স্বয়ংক্রিয়ভাবে এখানে সংরক্ষিত থাকবে।
              </p>
            </div>
          ) : (
            history.map((item) => {
              const cat = CATEGORIES.find((c) => c.id === item.category);
              const dateStr = new Date(item.timestamp).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={item.id}
                  onClick={() => {
                    audio.playTick();
                    onSelectHistoryItem(item);
                    onClose();
                  }}
                  className="p-3.5 rounded-2xl water-glass-card hover:bg-white/20 transition cursor-pointer group shadow-sm"
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5 text-nature-shadow">
                      <span>{cat?.icon || '📄'}</span>
                      <span>{cat?.name || item.category}</span>
                    </span>
                    <span className="text-[10px] text-white/80 font-mono text-nature-shadow">{dateStr}</span>
                  </div>
                  <p className="text-xs font-bold text-white line-clamp-1 mb-1 text-nature-shadow">
                    "{item.prompt}"
                  </p>
                  <p className="text-[11px] text-white/85 line-clamp-2 leading-relaxed text-nature-shadow">
                    {item.result.slice(0, 100)}...
                  </p>
                  <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] text-white font-semibold text-nature-shadow">
                    <span>পুনরায় লোড করুন</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
