import React from 'react';
import { ChevronRight, Zap, AlertCircle, Sparkles } from 'lucide-react';
import { audio } from '../utils/audio';

interface UserTelcoCardProps {
  credits?: number;
  onOpenRecharge: () => void;
  historyCount: number;
  onOpenGuide: () => void;
  userStatus?: string;
  lastTransactionId?: string | null;
}

export const UserTelcoCard: React.FC<UserTelcoCardProps> = ({
  onOpenRecharge,
  historyCount,
  userStatus = 'PRO সক্রিয়',
  lastTransactionId,
}) => {
  const isPro = userStatus === 'PRO সক্রিয়';

  return (
    <div className="space-y-3.5 mb-5 text-left">
      {/* 1. Main Hero Status Card — Minimal Frosted Glass matching uploaded reference image */}
      <div className="relative overflow-hidden rounded-3xl minimal-hero p-5 text-slate-800">
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5 flex-1 min-w-0">
            {/* Top label */}
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-700 text-[11px] font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>এআই সার্ভিস স্ট্যাটাস</span>
            </div>

            {/* Big Prominent Text */}
            <div className="flex items-center gap-2 flex-wrap pt-0.5">
              <span className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {isPro ? 'সীমাহীন অ্যাক্সেস' : 'স্ট্যান্ডার্ড অ্যাক্সেস'}
              </span>
              <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200 uppercase tracking-wider">
                {userStatus}
              </span>
            </div>

            {/* Subtitle */}
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              সার্বক্ষণিক উচ্চগতির ক্লাউড এআই ক্লাস্টার • শতভাগ নিরাপদ ও এনক্রিপ্টেড
            </p>
          </div>

          {/* Action Button */}
          <button
            type="button"
            onClick={() => {
              audio.playTick();
              onOpenRecharge();
            }}
            className="inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-2xl minimal-btn-primary text-white font-bold text-xs sm:text-sm shadow-md transition cursor-pointer shrink-0 self-start sm:self-auto"
          >
            <Zap className="w-4 h-4 fill-white text-white" />
            <span>প্যাকেজসমূহ</span>
          </button>
        </div>
      </div>

      {/* 2. Three Metrics Row with Minimal Clean Glass Cards */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="p-3.5 rounded-2xl minimal-card text-left">
          <div className="flex items-center gap-1.5 text-blue-600 text-sm font-black">
            <Zap className="w-4 h-4 fill-blue-500 text-blue-500" />
            <span>৪টি</span>
          </div>
          <p className="text-[11px] text-slate-600 font-bold mt-1">
            টুলস প্রস্তুত
          </p>
        </div>

        <div className="p-3.5 rounded-2xl minimal-card text-left">
          <div className="flex items-center gap-1.5 text-emerald-600 text-sm font-black">
            <Sparkles className="w-4 h-4 text-emerald-500" />
            <span>কোর</span>
          </div>
          <p className="text-[11px] text-slate-600 font-bold mt-1">
            ফুল স্পিড
          </p>
        </div>

        <div className="p-3.5 rounded-2xl minimal-card text-left">
          <div className="flex items-center gap-1.5 text-purple-600 text-sm font-black">
            <span className="text-xs">📜</span>
            <span>{historyCount}টি</span>
          </div>
          <p className="text-[11px] text-slate-600 font-bold mt-1">
            সম্পন্ন কাজ
          </p>
        </div>
      </div>

      {/* 3. Alert / Notice Banner (Clean pill with zero overlapping) */}
      <div
        onClick={() => {
          audio.playTick();
          onOpenRecharge();
        }}
        className="flex items-center justify-between gap-3 p-3 rounded-2xl minimal-pill hover:shadow-md text-slate-700 text-xs font-semibold cursor-pointer transition border border-slate-200/80"
      >
        <div className="flex items-center gap-2 min-w-0 flex-1 truncate">
          <AlertCircle className="w-4 h-4 text-blue-600 shrink-0" />
          <span className="truncate">
            ঘোষণা: নতুন প্রাতিষ্ঠানিক এআই মডেল সফলভাবে যুক্ত হয়েছে!
          </span>
        </div>
        <div className="flex items-center gap-0.5 text-xs text-blue-600 shrink-0 font-bold">
          <span>প্যাকেজসমূহ</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </div>
      </div>
    </div>
  );
};
