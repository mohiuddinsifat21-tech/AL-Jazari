import React, { useState } from 'react';
import {
  Copy,
  Check,
  Share2,
  RefreshCw,
  Sparkles,
  FileDown,
  FileText,
  CheckCircle2,
  Clock,
  ThumbsUp,
  ThumbsDown,
  Bookmark,
  BookmarkCheck,
  ShieldAlert,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import { audio } from '../utils/audio';
import { SecurityViolation } from '../types';
import { exportToStructuredPdf } from '../utils/pdfExport';

interface ResultDisplayProps {
  isLoading: boolean;
  error: string | null;
  result: string | null;
  securityViolation: SecurityViolation | null;
  onRetry: () => void;
  onClearSecurityWarning?: () => void;
  onOpenShare: (text: string) => void;
  loadingMessage: string;
  isBookmarked?: boolean;
  onToggleBookmark?: () => void;
  latencyMs?: number;
  estimatedTokens?: number;
  assistantName?: string;
  onFeedback?: (rating: 'like' | 'dislike') => void;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({
  isLoading,
  error,
  result,
  securityViolation,
  onRetry,
  onClearSecurityWarning,
  onOpenShare,
  loadingMessage,
  isBookmarked = false,
  onToggleBookmark,
  latencyMs,
  estimatedTokens,
  assistantName,
  onFeedback,
}) => {
  const [copied, setCopied] = useState(false);
  const [userFeedback, setUserFeedback] = useState<'like' | 'dislike' | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [pdfExportSuccess, setPdfExportSuccess] = useState(false);

  const handleDirectPdfExport = async () => {
    if (!result) return;
    audio.playTick();
    setIsExportingPdf(true);

    try {
      await exportToStructuredPdf({
        content: result,
        assistantName: assistantName || 'ক্যারিয়ার ও এআই বিশেষজ্ঞ',
        timestamp: Date.now(),
        documentTitle: 'আল-জাজারি AI ফলাফল ও প্রতিবেদন',
      });
      audio.playCash();
      setPdfExportSuccess(true);
      setTimeout(() => setPdfExportSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to export structured PDF:', err);
      // Fallback
      handleDownload('txt');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    audio.playTick();
    setTimeout(() => setCopied(false), 2200);
  };

  const handleShareClick = () => {
    if (!result) return;
    audio.playTick();
    if (navigator.share) {
      navigator.share({
        title: 'আল-জাজারি AI ফলাফল',
        text: result,
      }).catch(() => {
        onOpenShare(result);
      });
    } else {
      onOpenShare(result);
    }
  };

  const handleDownload = (format: 'md' | 'txt') => {
    if (!result) return;
    audio.playTick();
    const mimeType = format === 'md' ? 'text/markdown;charset=utf-8;' : 'text/plain;charset=utf-8;';
    const blob = new Blob([result], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `al-jazari-output-${Date.now()}.${format}`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    audio.playSuccess();
  };

  const handlePrintPdf = () => {
    if (!result) return;
    audio.playTick();
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>আল-জাজারি AI - প্রফেশনাল ডকুমেন্ট</title>
            <style>
              body { font-family: 'Hind Siliguri', 'Segoe UI', sans-serif; line-height: 1.6; padding: 40px; color: #1e293b; max-width: 800px; margin: 0 auto; }
              h1, h2, h3 { color: #0f172a; }
              hr { border: none; border-top: 1px solid #e2e8f0; margin: 24px 0; }
              .footer { margin-top: 40px; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 12px; }
            </style>
          </head>
          <body>
            <h2>আল-জাজারি AI (Al-Jazari AI)</h2>
            <p><strong>আগামীর জন্য বুদ্ধিমত্তার শক্তি</strong> | প্রস্তুত: ${new Date().toLocaleDateString('bn-BD')}</p>
            <hr />
            <div>${result.replace(/\n/g, '<br/>')}</div>
            <div class="footer">আল-জাজারি AI প্ল্যাটফর্ম দ্বারা প্রস্তুতকৃত • শতভাগ নিরাপদ ও ক্লাউড-এনক্রিপ্টেড</div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
    }
  };

  const handleRate = (rating: 'like' | 'dislike') => {
    setUserFeedback(rating);
    audio.playSuccess();
    if (onFeedback) onFeedback(rating);
  };

  // 1. CRITICAL SECURITY VIOLATION STATE (Hacking, Phishing, Spamming)
  if (securityViolation && securityViolation.isSecurityViolation) {
    const isHacking = securityViolation.threatType === 'hacking';
    const isPhishing = securityViolation.threatType === 'phishing';

    return (
      <div className="minimal-card rounded-3xl p-5 sm:p-7 shadow-xl mb-6 text-left border-2 border-rose-400/80 bg-rose-50/50 backdrop-blur-xl animate-shake relative overflow-hidden">
        {/* Top Glowing Security Pill */}
        <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-rose-200/80">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-md">
              <ShieldAlert className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-600 text-white shadow-sm">
                  {isHacking ? 'হ্যাকিং প্রতিরোধ' : isPhishing ? 'ফিশিং প্রতিরোধ' : 'স্প্যামিং প্রতিরোধ'}
                </span>
                <span className="text-[11px] font-bold text-rose-700">
                  নিরাপত্তা অ্যালার্ট
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-black text-rose-950 mt-0.5">
                {securityViolation.title || 'অননুমোদিত সাইবার কার্যকলাপ শনাক্ত হয়েছে'}
              </h3>
            </div>
          </div>
        </div>

        {/* Warning Content */}
        <div className="space-y-3">
          <p className="text-xs sm:text-sm text-rose-900 leading-relaxed font-semibold">
            {securityViolation.warningMessage}
          </p>

          {/* Safety Guidelines Card */}
          <div className="p-3.5 rounded-2xl bg-white/90 border border-rose-200 text-xs text-slate-700 space-y-1.5 shadow-sm">
            <div className="flex items-center gap-1.5 font-bold text-rose-800">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>আল-জাজারি AI সাইবার নিরাপত্তা ও দায়িত্বশীল এআই নীতিমালা:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-600 text-[11px] pl-1 font-medium">
              <li>এসকিউএল ইনজেকশন, এক্সএসএস, রিভার্স শেল বা সিস্টেম এক্সপ্লয়েট নিষিদ্ধ।</li>
              <li>ভুয়া লগইন পেজ, ওটিপি বা পিন ফাঁদ তৈরি ও ফিশিং কার্যক্রম কঠোরভাবে বারিত।</li>
              <li>স্বয়ংক্রিয় স্প্যাম বট, বাল্ক ম্যাস মেসেজিং বা ফ্লাডিং নিষিদ্ধ।</li>
            </ul>
          </div>

          {securityViolation.safetyAdvice && (
            <p className="text-[11px] text-slate-600 font-medium">
              💡 {securityViolation.safetyAdvice}
            </p>
          )}

          {/* Action to dismiss / rephrase */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                audio.playTick();
                if (onClearSecurityWarning) onClearSecurityWarning();
              }}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-sm cursor-pointer"
            >
              নিরাপদ ভাষায় পুনরায় লিখুন
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Loading State
  if (isLoading) {
    return (
      <div className="minimal-card rounded-3xl p-6 sm:p-8 text-center shadow-lg relative overflow-hidden mb-6">
        <div className="relative z-10 flex flex-col items-center justify-center space-y-4 max-w-md mx-auto">
          {/* Luminous Loading Pod */}
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 flex items-center justify-center p-3 shadow-sm">
              <img src="/icon.svg" alt="প্রক্রিয়াকরণ" className="w-full h-full object-contain animate-pulse" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-white border border-blue-400 flex items-center justify-center shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping" />
            </div>
          </div>

          <div className="space-y-1">
            <h3 className="text-base sm:text-lg font-black text-slate-900">
              প্রক্রিয়াকরণ চলছে…
            </h3>
            <p className="text-xs text-slate-600 font-medium">
              {loadingMessage || 'উপাত্ত বিশ্লেষণ ও ফলাফল প্রস্তুত করা হচ্ছে...'}
            </p>
          </div>

          {/* Minimal Progress Bar */}
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200/80 shadow-inner">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full w-4/5 animate-pulse rounded-full" />
          </div>

          <p className="text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            <span>নিরাপদ ক্লাউড এআই গণনা চলমান</span>
          </p>
        </div>
      </div>
    );
  }

  // 3. Error State
  if (error) {
    return (
      <div className="minimal-card rounded-3xl p-6 sm:p-8 text-center shadow-md mb-6 border-rose-200 bg-rose-50/50">
        <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto mb-3 text-2xl">
          ⚠️
        </div>
        <h3 className="text-base font-bold text-slate-900 mb-1">
          অনুরোধটি সম্পন্ন করা যায়নি
        </h3>
        <p className="text-xs text-slate-700 max-w-md mx-auto mb-4 font-medium leading-relaxed">
          {error}
        </p>

        <div className="flex flex-wrap items-center justify-center gap-2.5">
          <button
            type="button"
            onClick={onRetry}
            className="inline-flex items-center gap-2 minimal-pill px-4 py-2 rounded-xl text-xs font-bold text-slate-800 hover:text-blue-600 transition cursor-pointer shadow-sm"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>পুনরায় চেষ্টা করুন</span>
          </button>
        </div>
      </div>
    );
  }

  // 4. Idle / Empty State
  if (!result) {
    return (
      <div className="minimal-card rounded-3xl p-6 sm:p-8 text-center mb-6 border-dashed border-slate-200">
        <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-200 text-slate-400 flex items-center justify-center mx-auto mb-3 shadow-inner">
          <Sparkles className="w-6 h-6 stroke-[1.8] text-blue-600" />
        </div>
        <h4 className="text-sm font-bold text-slate-800 mb-1">
          আপনার ফলাফল এখানে প্রদর্শিত হবে
        </h4>
        <p className="text-xs text-slate-500 max-w-sm mx-auto font-medium">
          উপরের বক্সে আপনার প্রয়োজনীয় বিষয় লিখুন এবং ফলাফল প্রস্তুত করতে সাবমিট করুন।
        </p>
      </div>
    );
  }

  // 5. Success State & Results Panel
  return (
    <div className="minimal-card rounded-3xl p-5 sm:p-6 shadow-xl mb-6 text-left">
      {/* Success Notification Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-emerald-50/80 border border-emerald-200 rounded-2xl p-3.5 mb-4 shadow-sm">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-700 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 stroke-[2.4]" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-extrabold text-emerald-900">
              আপনার ফলাফল প্রস্তুত।
            </h4>
            <div className="flex items-center gap-2 text-[11px] text-emerald-700 font-medium">
              <span>{assistantName ? `${assistantName} দ্বারা প্রস্তুত` : 'আল-জাজারি AI দ্বারা প্রস্তুত'}</span>
              {latencyMs && (
                <>
                  <span>•</span>
                  <span>{Math.round(latencyMs) / 1000} সে.</span>
                </>
              )}
              {estimatedTokens && (
                <>
                  <span>•</span>
                  <span>{estimatedTokens} টোকেন</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Primary Action Buttons Row */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto flex-wrap">
          {/* 1-Click Copy */}
          <button
            onClick={handleCopy}
            className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer border ${
              copied
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'minimal-btn-primary text-white'
            }`}
            title="ফলাফল কপি করুন"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>কপি সম্পন্ন</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 stroke-[2.2]" />
                <span>কপি</span>
              </>
            )}
          </button>

          {/* Structured PDF Export Button */}
          <button
            onClick={handleDirectPdfExport}
            disabled={isExportingPdf}
            className={`inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer border active:scale-95 disabled:opacity-60 ${
              pdfExportSuccess
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white border-transparent'
            }`}
            title="সহজে প্রফেশনাল PDF ডকুমেন্ট হিসেবে এক্সপোর্ট করুন"
          >
            {isExportingPdf ? (
              <>
                <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>PDF তৈরি হচ্ছে...</span>
              </>
            ) : pdfExportSuccess ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[2.5]" />
                <span>PDF সংরক্ষিত!</span>
              </>
            ) : (
              <>
                <FileDown className="w-3.5 h-3.5 text-white" />
                <span>PDF এক্সপোর্ট</span>
              </>
            )}
          </button>

          {/* Bookmark / Pin Toggle */}
          <button
            onClick={() => {
              audio.playTick();
              if (onToggleBookmark) onToggleBookmark();
            }}
            className={`inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer border ${
              isBookmarked
                ? 'bg-amber-50 text-amber-700 border-amber-300'
                : 'minimal-pill text-slate-700 hover:text-blue-600'
            }`}
            title={isBookmarked ? 'সংরক্ষিত থেকে সরান' : 'বুকমার্ক করুন'}
          >
            {isBookmarked ? (
              <>
                <BookmarkCheck className="w-3.5 h-3.5 text-amber-600" />
                <span>সংরক্ষিত</span>
              </>
            ) : (
              <>
                <Bookmark className="w-3.5 h-3.5" />
                <span>বুকমার্ক</span>
              </>
            )}
          </button>

          {/* Share Action */}
          <button
            onClick={handleShareClick}
            className="inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold minimal-pill text-slate-700 hover:text-blue-600 transition shadow-sm cursor-pointer"
            title="শেয়ার করুন"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>শেয়ার</span>
          </button>
        </div>
      </div>

      {/* Main Content Render Area with pristine contrast and typography */}
      <div className="bg-slate-50/80 rounded-2xl p-4 sm:p-6 border border-slate-200/80 text-slate-800 text-sm sm:text-base leading-relaxed whitespace-pre-wrap font-sans selection:bg-blue-200 selection:text-slate-900 shadow-inner">
        {result}
      </div>

      {/* Additional Utility Toolbar: Export & Feedback */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
        {/* Export formats */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => handleDownload('md')}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg minimal-pill text-slate-700 hover:text-blue-600 transition cursor-pointer font-bold text-[11px]"
            title="Markdown হিসেবে সংরক্ষণ করুন"
          >
            <FileDown className="w-3.5 h-3.5 text-blue-600" />
            <span>.MD</span>
          </button>
          <button
            onClick={() => handleDownload('txt')}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg minimal-pill text-slate-700 hover:text-blue-600 transition cursor-pointer font-bold text-[11px]"
            title="Text হিসেবে সংরক্ষণ করুন"
          >
            <FileDown className="w-3.5 h-3.5 text-indigo-600" />
            <span>.TXT</span>
          </button>
          <button
            onClick={handleDirectPdfExport}
            disabled={isExportingPdf}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg minimal-pill text-slate-700 hover:text-emerald-600 transition cursor-pointer font-bold text-[11px] disabled:opacity-50"
            title="স্ট্রাকচার্ড PDF ডাউনলোড করুন"
          >
            {isExportingPdf ? (
              <span className="w-3 h-3 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
            ) : (
              <FileDown className="w-3.5 h-3.5 text-emerald-600" />
            )}
            <span>PDF</span>
          </button>
        </div>

        {/* Feedback Buttons */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500 font-medium">ফিডব্যাক:</span>
          <button
            onClick={() => handleRate('like')}
            className={`p-1.5 rounded-lg border transition cursor-pointer ${
              userFeedback === 'like'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-400 shadow-sm'
                : 'bg-white/80 text-slate-600 hover:text-emerald-600 border-slate-200'
            }`}
            title="ভালো হয়েছে"
          >
            <ThumbsUp className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleRate('dislike')}
            className={`p-1.5 rounded-lg border transition cursor-pointer ${
              userFeedback === 'dislike'
                ? 'bg-rose-50 text-rose-700 border-rose-400 shadow-sm'
                : 'bg-white/80 text-slate-600 hover:text-rose-600 border-slate-200'
            }`}
            title="উন্নতির সুযোগ আছে"
          >
            <ThumbsDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
