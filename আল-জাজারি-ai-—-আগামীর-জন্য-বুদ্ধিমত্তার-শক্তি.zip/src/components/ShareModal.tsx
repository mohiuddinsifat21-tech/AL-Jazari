import React, { useState } from 'react';
import { X, Copy, Check, MessageSquare, Share2, Facebook, Linkedin } from 'lucide-react';
import { audio } from '../utils/audio';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  resultText: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  resultText,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://al-jazari.ai';
  const shareSummary = `আল-জাজারি AI দ্বারা প্রস্তুতকৃত ফলাফল:\n\n"${resultText.slice(0, 180)}..."\n\nপ্ল্যাটফর্ম লিংক: ${currentUrl}`;

  const handleCopyText = () => {
    navigator.clipboard.writeText(shareSummary);
    setCopied(true);
    audio.playTick();
    setTimeout(() => setCopied(false), 2200);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'আল-জাজারি AI — ফলাফল',
          text: shareSummary,
          url: currentUrl,
        });
      } catch {
        // User dismissed
      }
    } else {
      handleCopyText();
    }
  };

  const shareToWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareSummary)}`;
    window.open(url, '_blank');
  };

  const shareToLinkedIn = () => {
    const url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(currentUrl)}`;
    window.open(url, '_blank');
  };

  const shareToFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}&quote=${encodeURIComponent(shareSummary)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl">
      <div className="relative w-full max-w-md rounded-3xl water-glass-card p-6 shadow-2xl text-left border border-white/40">
        <button
          onClick={() => {
            audio.playTick();
            onClose();
          }}
          className="absolute top-4 right-4 text-white hover:bg-white/20 p-2 rounded-xl water-glass-pill transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl water-glass-pill p-2 flex items-center justify-center shrink-0">
            <Share2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white text-nature-shadow">ফলাফল শেয়ার করুন</h3>
            <p className="text-xs text-white/90 text-nature-shadow">সহকর্মী ও প্ল্যাটফর্মে প্রেরণ</p>
          </div>
        </div>

        {/* Content Snippet Preview */}
        <div className="bg-black/30 p-3 rounded-2xl border border-white/20 text-xs text-white space-y-1 mb-4 shadow-inner">
          <p className="text-[11px] text-white/80 font-medium text-nature-shadow">শেয়ারের বিবরণ:</p>
          <p className="font-sans line-clamp-3 bg-white/10 p-2.5 rounded-xl border border-white/10 text-white text-nature-shadow">
            {shareSummary}
          </p>
        </div>

        {/* Channels */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <button
            onClick={shareToWhatsApp}
            className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-emerald-600/70 hover:bg-emerald-600 text-white font-bold text-xs shadow-md transition cursor-pointer border border-white/30"
          >
            <MessageSquare className="w-4 h-4" />
            <span>হোয়াটসঅ্যাপ</span>
          </button>
          <button
            onClick={shareToLinkedIn}
            className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-blue-700/70 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition cursor-pointer border border-white/30"
          >
            <Linkedin className="w-4 h-4" />
            <span>লিংকডইন</span>
          </button>
          <button
            onClick={shareToFacebook}
            className="flex items-center justify-center gap-1.5 p-2.5 rounded-xl bg-blue-600/70 hover:bg-blue-600 text-white font-bold text-xs shadow-md transition cursor-pointer border border-white/30"
          >
            <Facebook className="w-4 h-4" />
            <span>ফেসবুক</span>
          </button>
        </div>

        {/* Copy Button */}
        <button
          onClick={handleCopyText}
          className={`w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-md cursor-pointer mb-2 border ${
            copied
              ? 'bg-emerald-600/90 text-white border-white'
              : 'nature-glass-btn text-white text-nature-shadow'
          }`}
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>কপি সম্পন্ন হয়েছে</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>টেক্সট ও লিংক কপি করুন</span>
            </>
          )}
        </button>

        {typeof navigator !== 'undefined' && 'share' in navigator && (
          <button
            onClick={handleNativeShare}
            className="w-full py-2.5 px-4 rounded-xl water-glass-btn-secondary text-white text-xs font-semibold flex items-center justify-center gap-2 transition"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>অন্যান্য অ্যাপে পাঠান</span>
          </button>
        )}
      </div>
    </div>
  );
};
