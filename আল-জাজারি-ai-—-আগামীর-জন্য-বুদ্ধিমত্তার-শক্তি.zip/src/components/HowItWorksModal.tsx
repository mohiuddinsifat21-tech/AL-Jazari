import React, { useState } from 'react';
import { X, Smartphone, ArrowRight, HelpCircle, ShieldCheck } from 'lucide-react';
import { audio } from '../utils/audio';

interface HowItWorksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartNow: () => void;
}

export const HowItWorksModal: React.FC<HowItWorksModalProps> = ({
  isOpen,
  onClose,
  onStartNow,
}) => {
  const [activeTab, setActiveTab] = useState<'guide' | 'apk'>('guide');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xl overflow-y-auto">
      <div className="relative w-full max-w-lg rounded-3xl water-glass-card p-6 shadow-2xl text-left my-auto border border-white/40">
        <button
          onClick={() => {
            audio.playTick();
            onClose();
          }}
          className="absolute top-4 right-4 text-white hover:bg-white/20 p-2 rounded-xl water-glass-pill transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-11 h-11 rounded-2xl water-glass-pill p-2 flex items-center justify-center shrink-0 shadow-md">
            <img src="/icon.svg" alt="আল-জাজারি AI" className="w-full h-full object-contain drop-shadow" />
          </div>
          <div>
            <h3 className="text-lg sm:text-xl font-black text-white text-nature-shadow">ব্যবহার নির্দেশিকা ও প্ল্যাটফর্ম তথ্য</h3>
            <p className="text-xs text-white/90 text-nature-shadow">আল-জাজারি AI — আগামীর জন্য বুদ্ধিমত্তার শক্তি</p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-black/30 border border-white/20 mb-4">
          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setActiveTab('guide');
            }}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'guide'
                ? 'nature-glass-btn text-white shadow-md text-nature-shadow'
                : 'text-white/80 hover:text-white'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>কার্যপদ্ধতি ও নিয়মাবলী</span>
          </button>
          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setActiveTab('apk');
            }}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'apk'
                ? 'nature-glass-btn text-white shadow-md text-nature-shadow'
                : 'text-white/80 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>মোবাইল অ্যাপ ইনস্টল</span>
          </button>
        </div>

        {activeTab === 'guide' ? (
          <div className="space-y-2.5 mb-5">
            <div className="flex items-start gap-3 p-3 rounded-2xl water-glass-pill">
              <span className="w-6 h-6 rounded-xl bg-white/25 border border-white text-white font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 text-nature-shadow">
                ১
              </span>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white text-nature-shadow">কাজের ক্ষেত্র নির্বাচন</h4>
                <p className="text-[11px] text-white/85 mt-0.5 leading-relaxed text-nature-shadow">
                  শিক্ষা, ক্যারিয়ার, ফ্রিল্যান্সিং বা কনটেন্ট—আপনার প্রয়োজনীয় ক্যাটাগরি ও উপযুক্ত টোন নির্বাচন করুন।
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-2xl water-glass-pill">
              <span className="w-6 h-6 rounded-xl bg-white/25 border border-white text-white font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 text-nature-shadow">
                ২
              </span>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white text-nature-shadow">সুনির্দিষ্ট নির্দেশনা প্রদান</h4>
                <p className="text-[11px] text-white/85 mt-0.5 leading-relaxed text-nature-shadow">
                  বক্সে আপনার কাজের বিস্তারিত লিখুন বা প্রস্তুতকৃত নমুনা বিষয়ের উপর ক্লিক করুন।
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-2xl water-glass-pill">
              <span className="w-6 h-6 rounded-xl bg-white/25 border border-white text-white font-bold flex items-center justify-center text-xs shrink-0 mt-0.5 text-nature-shadow">
                ৩
              </span>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white text-nature-shadow">ফলাফল সংগ্রহ ও সংরক্ষণ</h4>
                <p className="text-[11px] text-white/85 mt-0.5 leading-relaxed text-nature-shadow">
                  ১-ক্লিকে তাৎক্ষণিক ফলাফল প্রস্তুত করুন এবং ফাইল আকারে ডাউনলোড করে সরাসরি ব্যবহার করুন।
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3 mb-5 text-xs text-white">
            <div className="p-3.5 rounded-2xl water-glass-pill space-y-2">
              <div className="flex items-center gap-2 text-white font-bold text-nature-shadow">
                <Smartphone className="w-4 h-4 text-white" />
                <span>অ্যান্ড্রয়েড ইনস্টলেশন (PWA WebAPK)</span>
              </div>
              <p className="text-white/90 text-[11px] leading-relaxed text-nature-shadow">
                Google Chrome ব্রাউজারে ডানদিকের ৩-ডট মেন্যুতে গিয়ে <strong>"Install app"</strong> বা <strong>"Add to Home Screen"</strong> নির্বাচন করলেই আপনার হোমস্ক্রিনে অ্যাপটি সরাসরি ইনস্টল হয়ে যাবে।
              </p>
            </div>

            <div className="p-3.5 rounded-2xl water-glass-pill space-y-2">
              <div className="flex items-center gap-2 text-white font-bold text-nature-shadow">
                <ShieldCheck className="w-4 h-4 text-emerald-300" />
                <span>ডেটা গোপনীয়তা ও সার্ভার নিরাপত্তা</span>
              </div>
              <p className="text-white/85 text-[11px] leading-relaxed text-nature-shadow">
                আল-জাজারি AI কোনো তৃতীয় পক্ষের সাথে আপনার স্পর্শকাতর তথ্য আদান-প্রদান করে না। সমস্ত জেনারেশন সুরক্ষিত এন্ড-টু-এন্ড এনক্রিপশনে সম্পন্ন হয়।
              </p>
            </div>
          </div>
        )}

        <button
          onClick={() => {
            audio.playTick();
            onClose();
            onStartNow();
          }}
          className="w-full py-3.5 px-4 rounded-2xl nature-glass-btn text-white font-extrabold text-sm shadow-xl flex items-center justify-center gap-2 transition cursor-pointer text-nature-shadow"
        >
          <span>ব্যবহার শুরু করুন</span>
          <ArrowRight className="w-4 h-4 stroke-[2.2]" />
        </button>
      </div>
    </div>
  );
};
