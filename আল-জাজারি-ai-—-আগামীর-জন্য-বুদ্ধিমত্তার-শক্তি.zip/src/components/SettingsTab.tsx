import React from 'react';
import { AppLanguage, ThemeMode } from '../types';
import { audio } from '../utils/audio';
import {
  Settings,
  Globe,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  ShieldCheck,
  Lock,
  Sparkles,
  HelpCircle,
  Activity,
  ArrowRight,
} from 'lucide-react';

interface SettingsTabProps {
  language: AppLanguage;
  onToggleLanguage: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onOpenGuide: () => void;
  onOpenRecharge: () => void;
  onOpenDiagnostics: () => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  language,
  onToggleLanguage,
  soundEnabled,
  onToggleSound,
  theme,
  onToggleTheme,
  onOpenGuide,
  onOpenRecharge,
  onOpenDiagnostics,
}) => {
  return (
    <div className="space-y-4 text-left">
      {/* Header Banner */}
      <div className="p-5 rounded-3xl minimal-hero text-slate-800 relative overflow-hidden">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-bold">
            <Settings className="w-3.5 h-3.5 text-blue-600" />
            <span>সিস্টেম কনফিগারেশন</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            সেটিংস ও নিরাপত্তা নীতিমালা
          </h2>
          <p className="text-xs text-slate-600 font-medium max-w-sm">
            ব্যবহারকারীর অভিজ্ঞতা, অডিও ফিডব্যাক ও সাইবার নিরাপত্তা নীতিমালা নিয়ন্ত্রণ করুন।
          </p>
        </div>
      </div>

      {/* 1. Interface & Preferences */}
      <div className="p-4 rounded-3xl minimal-card space-y-3 border border-slate-200/80">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
          ইন্টারফেস ও অভিজ্ঞতা সেটিংস
        </h3>

        <div className="divide-y divide-slate-100">
          {/* Language Toggle */}
          <div className="py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Globe className="w-4 h-4 text-blue-600" />
              <div>
                <p className="text-xs font-bold text-slate-800">অ্যাপের ভাষা (Language)</p>
                <p className="text-[11px] text-slate-500 font-medium">
                  {language === 'bn' ? 'বাংলা ভাষায় সক্রিয়' : 'English mode active'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                audio.playTick();
                onToggleLanguage();
              }}
              className="px-3 py-1.5 rounded-xl minimal-pill text-xs font-bold text-slate-800 hover:text-blue-600 transition cursor-pointer"
            >
              {language === 'bn' ? 'English-এ পরিবর্তন' : 'বাংলায় পরিবর্তন'}
            </button>
          </div>

          {/* Theme Mode Toggle */}
          <div className="py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {theme === 'dark' ? (
                <Moon className="w-4 h-4 text-indigo-600" />
              ) : (
                <Sun className="w-4 h-4 text-amber-500" />
              )}
              <div>
                <p className="text-xs font-bold text-slate-800">ডিসপ্লে থিম (Theme)</p>
                <p className="text-[11px] text-slate-500 font-medium">
                  {theme === 'dark' ? 'ডার্ক গ্লাসিক মোড' : 'লাইট গ্লাসিক মোড'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                audio.playTick();
                onToggleTheme();
              }}
              className="px-3 py-1.5 rounded-xl minimal-pill text-xs font-bold text-slate-800 hover:text-blue-600 transition cursor-pointer"
            >
              {theme === 'dark' ? 'লাইট মোড' : 'ডার্ক মোড'}
            </button>
          </div>

          {/* Audio Feedback Toggle */}
          <div className="py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-600" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-400" />
              )}
              <div>
                <p className="text-xs font-bold text-slate-800">সাউন্ড এফেক্টস (UI Sounds)</p>
                <p className="text-[11px] text-slate-500 font-medium">
                  {soundEnabled ? 'সাউন্ড সক্রিয়' : 'নিঃশব্দ মোড'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                onToggleSound();
                audio.playTick();
              }}
              className="px-3 py-1.5 rounded-xl minimal-pill text-xs font-bold text-slate-800 hover:text-blue-600 transition cursor-pointer"
            >
              {soundEnabled ? 'বন্ধ করুন' : 'চালু করুন'}
            </button>
          </div>
        </div>
      </div>

      {/* 2. ADMIN DIAGNOSTIC & INSTRUCTION SYSTEM */}
      <div className="p-4 rounded-3xl minimal-card space-y-3 border border-blue-200/90 bg-gradient-to-br from-blue-50/40 via-white to-slate-50">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm">
              <Activity className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                অ্যাডমিন ডায়াগনস্টিক ও ইনস্ট্রাকশন সিস্টেম
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                এরর ও হেলথ মনিটর, স্পেশাল অ্যাডমিন অ্যালার্ট এবং অটো সাজেশন
              </p>
            </div>
          </div>

          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-200">
            ACTIVE
          </span>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed font-medium">
          Gemini API Key, সার্ভার কানেকশন বা রিচার্জে কোনো টেকনিক্যাল প্রবলেম দেখা দিলে সিস্টেম সাথে সাথে ডিটেক্ট করে এবং সমাধানের স্পষ্ট ধাপে ধাপে নির্দেশনা (Step-by-step instructions) প্রদান করে।
        </p>

        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onOpenDiagnostics();
          }}
          className="w-full py-2.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-98 text-white text-xs font-bold shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <Activity className="w-3.5 h-3.5" />
          <span>ডায়াগনস্টিক ও ইনস্ট্রাকশন ড্যাশবোর্ড খুলুন</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 2. CYBERSECURITY POLICY & GUARDRAIL SPECIFICATION */}
      <div className="p-4 rounded-3xl minimal-card space-y-2.5 border border-slate-200/80">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>সাইবার নিরাপত্তা, অ্যান্টি-হ্যাকিং ও অ্যান্টি-ফিশিং নীতিমালা</span>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed font-medium">
          আল-জাজারি AI ব্যাকেন্ডে সক্রিয় সাইবার থ্রেট গার্ডরেইল ইঞ্জিন রয়েছে। প্রতিটি ইনপুট নিম্নোক্ত ৩টি ক্ষেত্রে স্বয়ংক্রিয়ভাবে অডিট করা হয়:
        </p>

        <div className="space-y-2 pt-1 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-blue-600" />
              ১. হ্যাকিং ও সিস্টেম এক্সপ্লয়েট প্রতিরোধ:
            </span>
            <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
              এসকিউএল ইনজেকশন, এক্সএসএস (XSS), রিভার্স শেল, ম্যালওয়্যার জেনারেশন, এবং প্রম্পট ইনজেকশন বা জেলব্রেক সনাক্ত করে তাত্ক্ষণিক ব্লক করা হয়।
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-indigo-600" />
              ২. ফিশিং ও গোপন তথ্য চুরি প্রতিরোধ:
            </span>
            <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
              ভুয়া লগইন পেজ ক্লোন, বিকাশ/নগদ পিন চুরি, ব্যাংক ওটিপি জালিয়াতি বা ক্রেডেনশিয়াল হারভেস্টিং তৈরির যেকোনো অপচেষ্টা বাতিল করা হয়।
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-purple-600" />
              ৩. স্প্যামিং ও বাল্ক বট প্রতিরোধ:
            </span>
            <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
              স্বয়ংক্রিয় এসএমএস বা কল বোম্বার, ম্যাস ইমেইল স্প্যামার বা বাণিজ্যিক প্রতারণামূলক ফ্লাডিং বট তৈরি প্রতিহত করা হয়।
            </p>
          </div>
        </div>
      </div>

      {/* 3. Guide & Package Links */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onOpenGuide();
          }}
          className="p-3.5 rounded-2xl minimal-card hover:border-blue-400 transition text-left cursor-pointer space-y-1"
        >
          <HelpCircle className="w-4 h-4 text-blue-600" />
          <p className="text-xs font-bold text-slate-800">ব্যবহার নির্দেশিকা</p>
          <p className="text-[10px] text-slate-500 font-medium">ধাপে ধাপে টিউটোরিয়াল</p>
        </button>

        <button
          type="button"
          onClick={() => {
            audio.playTick();
            onOpenRecharge();
          }}
          className="p-3.5 rounded-2xl minimal-card hover:border-blue-400 transition text-left cursor-pointer space-y-1"
        >
          <Sparkles className="w-4 h-4 text-emerald-600" />
          <p className="text-xs font-bold text-slate-800">প্যাকেজ ও প্ল্যান</p>
          <p className="text-[10px] text-slate-500 font-medium">সীমাহীন ক্লাউড অ্যাক্সেস</p>
        </button>
      </div>

      {/* App Version Info */}
      <div className="p-4 text-center text-xs text-slate-500 space-y-1 border-t border-slate-200/80 pt-4">
        <p className="font-black text-slate-800">
          আল-জাজারি AI (Al-Jazari AI) • v2.4
        </p>
        <p className="text-[11px] text-slate-500 font-medium">
          আগামীর জন্য বুদ্ধিমত্তার শক্তি • Google AI Studio ও Gemini 3.8 Flash দ্বারা চালিত
        </p>
      </div>
    </div>
  );
};
