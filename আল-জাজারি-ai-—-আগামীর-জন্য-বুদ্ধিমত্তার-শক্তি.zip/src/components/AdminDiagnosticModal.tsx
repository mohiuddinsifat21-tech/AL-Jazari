import React, { useState, useEffect } from 'react';
import {
  X,
  Activity,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  RefreshCw,
  Copy,
  Check,
  Cpu,
  Key,
  ShieldCheck,
  CreditCard,
  Wifi,
  ExternalLink,
  Terminal,
  Zap,
  Trash2,
  ArrowRight,
  Sparkles,
  Info,
} from 'lucide-react';
import { SystemHealthReport, DiagnosticIssue, DiagnosticSeverity } from '../types';
import { audio } from '../utils/audio';

interface AdminDiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeIssueId?: string | null;
  onRecheckRequested?: () => void;
}

export const AdminDiagnosticModal: React.FC<AdminDiagnosticModalProps> = ({
  isOpen,
  onClose,
  activeIssueId,
  onRecheckRequested,
}) => {
  const [report, setReport] = useState<SystemHealthReport | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRunningLivePing, setIsRunningLivePing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'issues' | 'overview' | 'simulator' | 'logs'>('issues');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedIssueId, setSelectedIssueId] = useState<string | null>(activeIssueId || null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Fetch diagnostics
  const fetchDiagnostics = async (showLoading = false) => {
    if (showLoading) setIsLoading(true);
    try {
      const res = await fetch('/api/admin/diagnostics');
      if (res.ok) {
        const data: SystemHealthReport = await res.json();
        setReport(data);
        if (data.activeIssues.length > 0 && !selectedIssueId) {
          setSelectedIssueId(data.activeIssues[0].id);
        }
      }
    } catch (err) {
      console.warn('Failed to fetch diagnostics:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchDiagnostics(true);
      if (activeIssueId) setSelectedIssueId(activeIssueId);
    }
  }, [isOpen, activeIssueId]);

  if (!isOpen) return null;

  // Run live system test
  const handleRunLiveTest = async () => {
    setIsRunningLivePing(true);
    audio.playTick();
    try {
      const res = await fetch('/api/admin/diagnostics/run-test', { method: 'POST' });
      if (res.ok) {
        await fetchDiagnostics();
        audio.playSuccess();
        showActionMessage('লাইভ হেলথ টেস্ট সফলভাবে সম্পন্ন হয়েছে!');
        if (onRecheckRequested) onRecheckRequested();
      }
    } catch {
      showActionMessage('লাইভ টেস্টের সময় সংযোগে বিঘ্ন ঘটেছে।');
    } finally {
      setIsRunningLivePing(false);
    }
  };

  // Simulate an issue for admin testing
  const handleSimulateScenario = async (scenario: string) => {
    audio.playTick();
    try {
      const res = await fetch('/api/admin/diagnostics/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario }),
      });
      if (res.ok) {
        const data = await res.json();
        await fetchDiagnostics();
        if (data.issue?.id) {
          setSelectedIssueId(data.issue.id);
          setActiveTab('issues');
        }
        showActionMessage('সিমুলেশন তৈরি হয়েছে: ইনস্ট্রাকশন বক্সে সমাধান পরীক্ষা করুন।');
      }
    } catch {
      showActionMessage('সিমুলেশন কল ব্যর্থ হয়েছে।');
    }
  };

  // Resolve / Dismiss an issue
  const handleResolveIssue = async (id: string) => {
    audio.playTick();
    try {
      await fetch('/api/admin/diagnostics/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      await fetchDiagnostics();
      audio.playSuccess();
      showActionMessage('সমস্যাটি সমাধানকৃত (Resolved) হিসেবে চিহ্নিত করা হয়েছে।');
    } catch {
      // ignore
    }
  };

  // Clear all issues
  const handleClearAllIssues = async () => {
    audio.playTick();
    try {
      await fetch('/api/admin/diagnostics/clear-all', { method: 'POST' });
      await fetchDiagnostics();
      setSelectedIssueId(null);
      audio.playSuccess();
      showActionMessage('সমস্ত সতর্কতা ও ইস্যু সফলভাবে মুছে ফেলা হয়েছে।');
    } catch {
      // ignore
    }
  };

  const showActionMessage = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(null), 3500);
  };

  // Copy text to clipboard
  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    audio.playTick();
    setTimeout(() => setCopiedId(null), 2000);
  };

  const activeIssues = report?.activeIssues || [];
  const selectedIssue = activeIssues.find((i) => i.id === selectedIssueId) || activeIssues[0];

  const getSeverityBadge = (sev: DiagnosticSeverity) => {
    switch (sev) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[11px] font-black border border-rose-200">
            <AlertOctagon className="w-3 h-3 text-rose-600" />
            <span>সংকটজনক (Critical)</span>
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-black border border-amber-200">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            <span>সতর্কতা (Warning)</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-black border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>স্বাভাবিক (Healthy)</span>
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-md animate-fadeIn overflow-y-auto">
      <div className="w-full max-w-4xl max-h-[92vh] flex flex-col bg-white/95 backdrop-blur-2xl rounded-3xl border border-white/90 shadow-2xl overflow-hidden text-left my-auto">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200/80 flex items-center justify-between gap-3 bg-slate-50/80 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                  অ্যাডমিন ডায়াগনস্টিক ও ইনস্ট্রাকশন সিস্টেম
                </h3>
                <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-700 text-[10px] font-black border border-blue-200">
                  HEALTH MONITOR
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                রিয়েল-টাইম এরর ডিটেকশন, স্টেপ-বাই-স্টেপ সমাধান ও অটো সাজেশন গাইড
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRunLiveTest}
              disabled={isRunningLivePing}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-sm cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRunningLivePing ? 'animate-spin' : ''}`} />
              <span>{isRunningLivePing ? 'টেস্ট চলছে...' : 'লাইভ টেস্ট চালান'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                audio.playTick();
                onClose();
              }}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action toast message */}
        {actionSuccessMsg && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-5 py-2 text-xs font-bold text-emerald-800 flex items-center gap-2 animate-fadeIn shrink-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{actionSuccessMsg}</span>
          </div>
        )}

        {/* Sub-Navigation Tabs */}
        <div className="px-5 pt-3 pb-2 border-b border-slate-200/80 bg-white flex items-center gap-2 overflow-x-auto shrink-0">
          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setActiveTab('issues');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'issues'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>সক্রিয় সমস্যা ও সমাধান ({activeIssues.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setActiveTab('overview');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'overview'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>সিস্টেম হেলথ সারসংক্ষেপ</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setActiveTab('simulator');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'simulator'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>টেস্ট এরর সিমুলেশন</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audio.playTick();
              setActiveTab('logs');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'logs'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>ডায়াগনস্টিক রিপোর্ট ও লগ</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {isLoading ? (
            <div className="py-16 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mx-auto" />
              <p className="text-xs font-bold text-slate-700">সিস্টেম ডায়াগনস্টিক স্ক্যান চলছে...</p>
            </div>
          ) : (
            <>
              {/* TAB 1: ISSUES & STEP-BY-STEP INSTRUCTION DASHBOARD */}
              {activeTab === 'issues' && (
                <div className="space-y-4">
                  {/* Status Banner */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-wrap items-center justify-between gap-3 shadow-md">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-3.5 h-3.5 rounded-full ${
                          activeIssues.length === 0
                            ? 'bg-emerald-400 animate-pulse'
                            : activeIssues.some((i) => i.severity === 'critical')
                            ? 'bg-rose-500 animate-ping'
                            : 'bg-amber-400 animate-pulse'
                        }`}
                      />
                      <div>
                        <h4 className="text-sm font-black">
                          {activeIssues.length === 0
                            ? 'সব সার্ভিস সুস্থ ও সক্রিয় (All Systems Healthy)'
                            : `${activeIssues.length}টি টেকনিক্যাল বিষয় দৃষ্টি আকর্ষণ করছে`}
                        </h4>
                        <p className="text-xs text-slate-300 font-medium">
                          {activeIssues.length === 0
                            ? 'Gemini API, সাইবার ফায়ারওয়াল ও স্টোরেজ ১০০% কার্যক্ষম।'
                            : 'নিচের স্পেশাল মেসেজ বক্স ও স্টেপ-বাই-স্টেপ সমাধান অনুসরণ করুন।'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleRunLiveTest}
                        disabled={isRunningLivePing}
                        className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isRunningLivePing ? 'animate-spin' : ''}`} />
                        <span>পুনরায় স্ক্যান</span>
                      </button>
                      {activeIssues.length > 0 && (
                        <button
                          type="button"
                          onClick={handleClearAllIssues}
                          className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/30 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>সব ক্লিয়ার</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {activeIssues.length === 0 ? (
                    /* Healthy State */
                    <div className="p-8 rounded-3xl bg-emerald-50/60 border border-emerald-200 text-center space-y-3">
                      <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                        <CheckCircle2 className="w-7 h-7" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-base font-black text-slate-900">
                          অভিনন্দন! কোনো সক্রিয় ত্রুটি পাওয়া যায়নি
                        </h4>
                        <p className="text-xs text-slate-600 font-medium max-w-md mx-auto leading-relaxed">
                          আল-জাজারি AI-এর ব্যাকেন্ড ইঞ্জিন, Gemini 3.8 Flash মডেল, থ্রেট গার্ডরেল ও ডাটাবেস সম্পূর্ণ ত্রুটিমুক্তভাবে চালু আছে।
                        </p>
                      </div>

                      <div className="pt-2 flex justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleSimulateScenario('quota_limit')}
                          className="px-4 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-xs font-bold text-slate-700 shadow-sm transition cursor-pointer"
                        >
                          🧪 টেস্ট এরর সিমুলেশন করুন
                        </button>
                        <button
                          type="button"
                          onClick={handleRunLiveTest}
                          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm transition cursor-pointer"
                        >
                          ⚡ লাইভ কানেকশন টেস্ট
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Active Issues Split Screen */
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                      {/* Left: Issues List */}
                      <div className="md:col-span-4 space-y-2">
                        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                          চিহ্নিত সমস্যা তালিকা
                        </p>
                        <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
                          {activeIssues.map((issue) => {
                            const isSelected = issue.id === (selectedIssue?.id || '');
                            return (
                              <button
                                key={issue.id}
                                type="button"
                                onClick={() => {
                                  audio.playTick();
                                  setSelectedIssueId(issue.id);
                                }}
                                className={`w-full text-left p-3 rounded-2xl border transition cursor-pointer ${
                                  isSelected
                                    ? 'bg-blue-50/80 border-blue-400 shadow-sm'
                                    : 'bg-white hover:bg-slate-50 border-slate-200'
                                }`}
                              >
                                <div className="flex items-center justify-between gap-1 mb-1">
                                  {getSeverityBadge(issue.severity)}
                                  <span className="text-[10px] text-slate-400 font-medium">
                                    {new Date(issue.timestamp).toLocaleTimeString([], {
                                      hour: '2-digit',
                                      minute: '2-digit',
                                    })}
                                  </span>
                                </div>
                                <h5 className="text-xs font-bold text-slate-900 leading-snug line-clamp-2">
                                  {issue.title}
                                </h5>
                                <p className="text-[11px] text-slate-500 font-medium line-clamp-1 mt-0.5">
                                  {issue.detectedProblem}
                                </p>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Right: Detailed Instruction Dashboard / Admin Alert (স্পেশাল মেসেজ বক্স) */}
                      {selectedIssue && (
                        <div className="md:col-span-8 space-y-3">
                          {/* SPECIAL ADMIN ALERT BOX */}
                          <div
                            className={`p-4 rounded-3xl border shadow-sm space-y-3 ${
                              selectedIssue.severity === 'critical'
                                ? 'bg-rose-50/70 border-rose-300'
                                : 'bg-amber-50/70 border-amber-300'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2">
                                {selectedIssue.severity === 'critical' ? (
                                  <AlertOctagon className="w-5 h-5 text-rose-600 shrink-0" />
                                ) : (
                                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                                )}
                                <div>
                                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-600">
                                    স্পেশাল অ্যাডমিন অ্যালার্ট মেসেজ বক্স
                                  </span>
                                  <h4 className="text-sm sm:text-base font-black text-slate-900">
                                    {selectedIssue.title}
                                  </h4>
                                </div>
                              </div>
                              {getSeverityBadge(selectedIssue.severity)}
                            </div>

                            {/* Detected Problem Box */}
                            <div className="p-3 rounded-2xl bg-white/90 border border-slate-200/90 space-y-1">
                              <p className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-rose-500" />
                                বর্তমানে এই প্রবলেমটি হয়েছে:
                              </p>
                              <p className="text-xs text-slate-700 font-medium leading-relaxed">
                                {selectedIssue.detectedProblem}
                              </p>
                              {selectedIssue.detectedProblemEn && (
                                <p className="text-[11px] text-slate-500 font-mono italic">
                                  System: {selectedIssue.detectedProblemEn}
                                </p>
                              )}
                            </div>

                            {/* Root Cause Box */}
                            <div className="p-3 rounded-2xl bg-white/90 border border-slate-200/90 space-y-1">
                              <p className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-amber-500" />
                                মূল কারণ (Root Cause):
                              </p>
                              <p className="text-xs text-slate-700 font-medium">
                                {selectedIssue.rootCause}
                              </p>
                            </div>

                            {/* Auto Suggestion Pill */}
                            <div className="p-3 rounded-2xl bg-blue-50/90 border border-blue-200 space-y-1">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-[11px] font-black text-blue-900 flex items-center gap-1">
                                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                                  অটো সাজেশন (Auto Suggestion):
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleCopyText(
                                      selectedIssue.stepByStepInstructions.join('\n'),
                                      'suggest_' + selectedIssue.id
                                    )
                                  }
                                  className="text-[10px] font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
                                >
                                  {copiedId === 'suggest_' + selectedIssue.id ? (
                                    <>
                                      <Check className="w-3 h-3 text-emerald-600" />
                                      <span>কপি সম্পন্ন</span>
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-3 h-3" />
                                      <span>গাইড কপি করুন</span>
                                    </>
                                  )}
                                </button>
                              </div>
                              <p className="text-xs font-mono text-blue-800 bg-white/70 p-2 rounded-xl border border-blue-150">
                                {selectedIssue.stepByStepInstructions[0] || 'Check system configurations.'}
                              </p>
                            </div>

                            {/* Step-by-step instructions */}
                            <div className="space-y-2 pt-1">
                              <p className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                                <Terminal className="w-3.5 h-3.5 text-blue-600" />
                                এটি সমাধান করার জন্য এই স্টেপগুলো (Step-by-step instructions) অনুসরণ করুন:
                              </p>

                              <div className="space-y-2">
                                {selectedIssue.stepByStepInstructions.map((step, idx) => (
                                  <div
                                    key={idx}
                                    className="p-2.5 rounded-xl bg-white/95 border border-slate-200 flex items-start gap-2.5 text-xs font-medium text-slate-800"
                                  >
                                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-black text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                                      {idx + 1}
                                    </span>
                                    <div className="flex-1 leading-relaxed">
                                      <span>{step}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Bottom Resolution Actions */}
                            <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200">
                              <button
                                type="button"
                                onClick={() => handleResolveIssue(selectedIssue.id)}
                                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>ধাপগুলো সম্পন্ন হয়েছে (Mark as Resolved)</span>
                              </button>

                              <button
                                type="button"
                                onClick={handleRunLiveTest}
                                className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                              >
                                <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
                                <span>পুনরায় টেস্ট করুন</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: SYSTEM HEALTH OVERVIEW */}
              {activeTab === 'overview' && report && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3.5 rounded-2xl minimal-card border border-slate-200">
                      <div className="flex items-center justify-between text-slate-400 mb-1">
                        <Cpu className="w-4 h-4 text-blue-600" />
                        <span className="text-[10px] font-bold text-slate-500">ENGINE</span>
                      </div>
                      <p className="text-base font-black text-slate-900">Gemini 3.8 Flash</p>
                      <p className="text-[11px] text-emerald-600 font-bold mt-0.5 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>সক্রিয় ও প্রস্তুত</span>
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl minimal-card border border-slate-200">
                      <div className="flex items-center justify-between text-slate-400 mb-1">
                        <Key className="w-4 h-4 text-amber-500" />
                        <span className="text-[10px] font-bold text-slate-500">API KEY</span>
                      </div>
                      <p className="text-base font-black text-slate-900">
                        {report.checks.geminiApi.hasKey ? 'কনফিগারড' : 'অনুপস্থিত'}
                      </p>
                      <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                        {report.checks.geminiApi.latencyMs
                          ? `ল্যাটেন্সি: ${report.checks.geminiApi.latencyMs}ms`
                          : 'স্বাভাবিক'}
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl minimal-card border border-slate-200">
                      <div className="flex items-center justify-between text-slate-400 mb-1">
                        <ShieldCheck className="w-4 h-4 text-indigo-600" />
                        <span className="text-[10px] font-bold text-slate-500">FIREWALL</span>
                      </div>
                      <p className="text-base font-black text-slate-900">Active Shield</p>
                      <p className="text-[11px] text-indigo-600 font-bold mt-0.5">
                        {report.checks.securityEngine.blockedThreatsCount}টি হুমকি প্রতিহত
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl minimal-card border border-slate-200">
                      <div className="flex items-center justify-between text-slate-400 mb-1">
                        <Activity className="w-4 h-4 text-emerald-600" />
                        <span className="text-[10px] font-bold text-slate-500">UPTIME</span>
                      </div>
                      <p className="text-base font-black text-slate-900">
                        {Math.floor(report.uptimeSeconds / 60)} মি. {report.uptimeSeconds % 60} সে.
                      </p>
                      <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                        র‍্যাম: {report.memoryUsageMb} MB
                      </p>
                    </div>
                  </div>

                  {/* Service Checks Deep Dive */}
                  <div className="p-4 rounded-3xl border border-slate-200 bg-white space-y-3">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      সার্ভিস হেলথ চেকলিস্ট
                    </h4>

                    <div className="divide-y divide-slate-100 text-xs">
                      <div className="py-2.5 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <div>
                            <p className="font-bold text-slate-800">Google Gemini API Gateway</p>
                            <p className="text-[11px] text-slate-500">{report.checks.geminiApi.message}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                          OPERATIONAL
                        </span>
                      </div>

                      <div className="py-2.5 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <div>
                            <p className="font-bold text-slate-800">সাইবার থ্রেট গার্ডরেইল ইঞ্জিন</p>
                            <p className="text-[11px] text-slate-500">{report.checks.securityEngine.message}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                          PROTECTED
                        </span>
                      </div>

                      <div className="py-2.5 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <div>
                            <p className="font-bold text-slate-800">পার্সোনাল এআই অ্যাসিস্ট্যান্ট স্টোর</p>
                            <p className="text-[11px] text-slate-500">{report.checks.assistantsStore.message}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                          SYNCHRONIZED
                        </span>
                      </div>

                      <div className="py-2.5 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <div>
                            <p className="font-bold text-slate-800">SSLCommerz Sandbox Gateway (aljaz6ad61153dae8f)</p>
                            <p className="text-[11px] text-slate-500">{report.checks.rechargeGateway.message} • {report.checks.rechargeGateway.mode}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                          SSLCOMMERZ v4
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: ADMIN ERROR SIMULATOR */}
              {activeTab === 'simulator' && (
                <div className="space-y-4">
                  <div className="p-4 rounded-3xl bg-amber-50/70 border border-amber-200 space-y-2">
                    <h4 className="text-xs font-black text-amber-900 flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-amber-600" />
                      অ্যাডমিন টেস্ট এরর সিমুলেশন বেঞ্চ
                    </h4>
                    <p className="text-xs text-amber-800 font-medium leading-relaxed">
                      টেকনিক্যাল সমস্যা হলে সিস্টেম কীভাবে সতর্কবার্তা (Alert) এবং ধাপে ধাপে সমাধান গাইড (Instructions) প্রদর্শন করে তা আপনি নিজে পরখ করতে পারেন। নিচের যেকোনো সিনারিওতে ক্লিক করুন:
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">১. Gemini API কোটা লিমিট (429)</span>
                        <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 font-black text-[10px]">
                          QUOTA HIT
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium">
                        সিমুলেট করে দেখুন যখন Google Cloud API সীমা অতিক্রম করে তখন কী গাইড পাওয়া যায়।
                      </p>
                      <button
                        type="button"
                        onClick={() => handleSimulateScenario('quota_limit')}
                        className="w-full py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                      >
                        সিমুলেট করুন (Quota Limit)
                      </button>
                    </div>

                    <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">২. API Key অনুপস্থিত বা মেয়াদোত্তীর্ণ</span>
                        <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 font-black text-[10px]">
                          CRITICAL
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium">
                        API Key নষ্ট হলে অ্যাডমিন কনসোলে সঠিক Google AI Studio ডিরেকশন কেমন দেখায়।
                      </p>
                      <button
                        type="button"
                        onClick={() => handleSimulateScenario('api_key_fail')}
                        className="w-full py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                      >
                        সিমুলেট করুন (Invalid API Key)
                      </button>
                    </div>

                    <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">৩. রিচার্জ ও পেমেন্ট সার্ভিস ব্লক</span>
                        <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-black text-[10px]">
                          PAYMENT
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium">
                        প্যাকেজ রিচার্জ বা ব্যালেন্স সিঙ্ক আটকে গেলে রিকভারি স্টেপ টেস্ট করুন।
                      </p>
                      <button
                        type="button"
                        onClick={() => handleSimulateScenario('recharge_fail')}
                        className="w-full py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                      >
                        সিমুলেট করুন (Recharge Anomaly)
                      </button>
                    </div>

                    <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">৪. ক্লাউড নেটওয়ার্ক ড্রপ বা অফলাইন</span>
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 font-black text-[10px]">
                          NETWORK
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium">
                        ইন্টারনেট সাময়িক বিচ্ছিন্ন হলে অফলাইন মেকানিজম কীভাবে রিকভার করে।
                      </p>
                      <button
                        type="button"
                        onClick={() => handleSimulateScenario('network_drop')}
                        className="w-full py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                      >
                        সিমুলেট করুন (Network Drop)
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: DIAGNOSTIC LOGS & EXPORT */}
              {activeTab === 'logs' && report && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                        সিস্টেম ডায়াগনস্টিক রিপোর্ট
                      </h4>
                      <p className="text-[11px] text-slate-500 font-medium">
                        যেকোনো প্রযুক্তিগত সহায়তার জন্য এই লগ কপি করে পাঠাতে পারেন।
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        handleCopyText(JSON.stringify(report, null, 2), 'diag_full_log')
                      }
                      className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      {copiedId === 'diag_full_log' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>কপি সম্পন্ন</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>সম্পূর্ণ লগ কপি করুন</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-900 text-slate-200 font-mono text-[11px] overflow-x-auto max-h-[360px] leading-relaxed">
                    <pre>{JSON.stringify(report, null, 2)}</pre>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-200/80 bg-slate-50/80 flex items-center justify-between text-xs text-slate-500 font-medium shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>আল-জাজারি AI অটোনোমাস ডায়াগনস্টিক ইঞ্জিন সক্রিয়</span>
          </div>

          <button
            type="button"
            onClick={() => {
              audio.playTick();
              onClose();
            }}
            className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold transition cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
