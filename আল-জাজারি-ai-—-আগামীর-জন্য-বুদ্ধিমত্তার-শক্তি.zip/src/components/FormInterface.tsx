import React, { useState, useRef, useEffect } from 'react';
import { CategoryId, ToneId, AttachedFile, AssistantInfo, AppLanguage } from '../types';
import { CATEGORIES, TONES } from '../data/categories';
import { audio } from '../utils/audio';
import {
  Send,
  Shuffle,
  Trash2,
  Cpu,
  Sparkles,
  Mic,
  MicOff,
  Paperclip,
  FileText,
  Image as ImageIcon,
  X,
  Globe,
  Bot,
} from 'lucide-react';

interface FormInterfaceProps {
  category: CategoryId;
  tone: ToneId;
  prompt: string;
  onChangePrompt: (val: string) => void;
  onChangeTone: (t: ToneId) => void;
  onSubmit: () => void;
  isLoading: boolean;
  credits: number;
  onOpenRecharge: () => void;
  attachedFile: AttachedFile | null;
  onAttachFile: (file: AttachedFile | null) => void;
  language: AppLanguage;
  onToggleLanguage: () => void;
  activeAssistant: AssistantInfo | null;
  onOpenAssistants: () => void;
}

export const FormInterface: React.FC<FormInterfaceProps> = ({
  category,
  tone,
  prompt,
  onChangePrompt,
  onChangeTone,
  onSubmit,
  isLoading,
  attachedFile,
  onAttachFile,
  language,
  onToggleLanguage,
  activeAssistant,
  onOpenAssistants,
}) => {
  const [errorShake, setErrorShake] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const currentCategory = CATEGORIES.find((c) => c.id === category) || CATEGORIES[0];

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = language === 'bn' ? 'bn-BD' : 'en-US';

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        onChangePrompt(prompt ? `${prompt} ${transcript}` : transcript);
        audio.playSuccess();
      }
      setIsRecording(false);
    };

    recognition.onerror = () => {
      setIsRecording(false);
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognitionRef.current = recognition;
  }, [language, prompt, onChangePrompt]);

  const toggleVoiceRecording = () => {
    audio.playTick();
    if (!speechSupported || !recognitionRef.current) {
      alert(
        language === 'bn'
          ? 'আপনার ব্রাউজারে স্পিচ-টু-টেক্সট সেবা সমর্থিত নয়। ক্রোম বা এজ ব্রাউজার ব্যবহার করুন।'
          : 'Speech-to-text is not supported in this browser. Please use Chrome or Edge.'
      );
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      try {
        recognitionRef.current.lang = language === 'bn' ? 'bn-BD' : 'en-US';
        recognitionRef.current.start();
        setIsRecording(true);
      } catch (err) {
        console.warn('Speech recognition start failed:', err);
        setIsRecording(false);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      alert(
        language === 'bn'
          ? 'ফাইল সাইজ ১৫ মেগাবাইট এর বেশি হতে পারবে না।'
          : 'File size must not exceed 15MB.'
      );
      return;
    }

    audio.playTick();
    const reader = new FileReader();

    reader.onload = () => {
      const base64Data = (reader.result as string).split(',')[1] || '';
      onAttachFile({
        name: file.name,
        type: file.type || 'application/octet-stream',
        size: file.size,
        dataUrl: base64Data,
      });
      audio.playSuccess();
    };

    reader.readAsDataURL(file);
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSurpriseMe = () => {
    audio.playTick();
    const prompts = currentCategory.quickPrompts;
    const random = prompts[Math.floor(Math.random() * prompts.length)];
    onChangePrompt(random);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() && !attachedFile) {
      setErrorShake(true);
      setTimeout(() => setErrorShake(false), 500);
      return;
    }
    onSubmit();
  };

  return (
    <div className="minimal-card rounded-3xl p-5 shadow-lg mb-6 relative text-left">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,.pdf,.txt,.md,.doc,.docx"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Section 2 Header with Assistant Tag and Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 mb-4 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shadow-[0_0_8px_rgba(37,99,235,0.4)]" />
          <h3 className="text-xs sm:text-sm font-black text-slate-900 uppercase tracking-wider">
            {language === 'bn' ? '২. নির্দেশিকা ও ভাষা শৈলী:' : '2. Prompt & System Tone:'}
          </h3>
        </div>

        {/* Right side: Assistant Pill & Language Toggle */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Active Assistant Badge */}
          <button
            type="button"
            onClick={() => {
              audio.playTick();
              onOpenAssistants();
            }}
            className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700 hover:text-blue-600 minimal-pill px-2.5 py-1 rounded-full transition cursor-pointer shadow-sm"
            title="সহকারী পরিবর্তন বা পরিচালনা করুন"
          >
            <Bot className="w-3.5 h-3.5 text-blue-600" />
            <span className="truncate max-w-[110px]">
              {activeAssistant ? activeAssistant.name : (language === 'bn' ? 'আল-জাজারি কোর' : 'Core Agent')}
            </span>
          </button>

          {/* Language Toggle BN / EN */}
          <button
            type="button"
            onClick={() => {
              audio.playTick();
              onToggleLanguage();
            }}
            className="inline-flex items-center gap-1 text-[11px] font-black text-slate-700 hover:text-blue-600 minimal-pill px-2.5 py-1 rounded-full transition cursor-pointer shadow-sm"
            title="ভাষা পরিবর্তন (BN / EN)"
          >
            <Globe className="w-3.5 h-3.5 text-indigo-600" />
            <span>{language === 'bn' ? 'বাংলা' : 'English'}</span>
          </button>

          {/* Sample Topic Generator */}
          <button
            type="button"
            onClick={handleSurpriseMe}
            className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700 hover:text-blue-600 minimal-pill px-2.5 py-1 rounded-full transition cursor-pointer shadow-sm"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'নমুনা' : 'Sample'}</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleFormSubmit} className="space-y-4">
        {/* Tone Selection Buttons */}
        <div>
          <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-2">
            {language === 'bn' ? 'ভাষার প্রকাশভঙ্গি (Tone):' : 'Communication Tone:'}
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {TONES.map((t) => {
              const isSelected = t.id === tone;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    audio.playTick();
                    onChangeTone(t.id);
                  }}
                  className={`flex flex-col p-2.5 rounded-2xl border text-left transition cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50/90 border-blue-500 shadow-sm'
                      : 'bg-white/80 hover:bg-white text-slate-700 border-slate-200/80'
                  }`}
                >
                  <span className={`text-xs font-bold mb-0.5 ${isSelected ? 'text-blue-700' : 'text-slate-800'}`}>
                    {t.name}
                  </span>
                  <p className="text-[10px] text-slate-500 line-clamp-1 font-medium">
                    {t.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Prompt Input Field with Multi-Modal Toolbar inside */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
              {language === 'bn' ? 'আপনার নির্দেশনা বা বিস্তারিত তথ্য:' : 'Your Prompt & Instructions:'}
            </label>

            {/* Voice and Attachment Buttons */}
            <div className="flex items-center gap-1.5">
              {/* Voice Recording Button */}
              <button
                type="button"
                onClick={toggleVoiceRecording}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold transition shadow-sm cursor-pointer border ${
                  isRecording
                    ? 'bg-rose-50 text-rose-600 border-rose-400 animate-pulse'
                    : 'minimal-pill text-slate-700 hover:text-blue-600'
                }`}
                title={isRecording ? 'ভয়েস রেকর্ডিং চলছে' : 'ভয়েস দিয়ে ইনপুট দিন'}
              >
                {isRecording ? (
                  <>
                    <MicOff className="w-3.5 h-3.5 text-rose-600 animate-spin" />
                    <span className="text-[11px]">শুনছি…</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-3.5 h-3.5 text-blue-600" />
                    <span className="text-[11px]">ভয়েস</span>
                  </>
                )}
              </button>

              {/* File Attachment Button */}
              <button
                type="button"
                onClick={() => {
                  audio.playTick();
                  fileInputRef.current?.click();
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold minimal-pill text-slate-700 hover:text-blue-600 transition shadow-sm cursor-pointer"
                title="ফাইল বা ছবি সংযুক্ত করুন"
              >
                <Paperclip className="w-3.5 h-3.5 text-blue-600" />
                <span className="text-[11px]">ফাইল/ছবি</span>
              </button>
            </div>
          </div>

          <div className={`relative transition-transform ${errorShake ? 'animate-shake' : ''}`}>
            <textarea
              value={prompt}
              onChange={(e) => onChangePrompt(e.target.value)}
              disabled={isLoading}
              rows={4}
              placeholder={currentCategory.placeholder}
              className="w-full minimal-input rounded-2xl p-4 text-sm sm:text-base focus:outline-none transition resize-none disabled:opacity-50"
              maxLength={2000}
            />

            {/* Attached File Preview Badge (if attached) */}
            {attachedFile && (
              <div className="mx-2 mb-2 p-2.5 rounded-xl bg-blue-50/80 border border-blue-200 flex items-center justify-between gap-2 shadow-sm">
                <div className="flex items-center gap-2 min-w-0">
                  {attachedFile.type.startsWith('image/') ? (
                    <ImageIcon className="w-4 h-4 text-blue-600 shrink-0" />
                  ) : (
                    <FileText className="w-4 h-4 text-indigo-600 shrink-0" />
                  )}
                  <span className="text-xs font-bold text-slate-800 truncate">
                    {attachedFile.name}
                  </span>
                  <span className="text-[10px] text-slate-500 font-semibold shrink-0">
                    ({Math.round(attachedFile.size / 1024)} KB)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    audio.playTick();
                    onAttachFile(null);
                  }}
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                  title="ফাইল বাদ দিন"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Bottom info bar inside textarea */}
            <div className="flex items-center justify-between text-xs text-slate-500 px-1 pt-1.5 font-medium">
              <div className="flex items-center gap-2">
                <span>{prompt.length} / ২০০০ বর্ণ</span>
                {prompt.length > 0 && (
                  <button
                    type="button"
                    onClick={() => onChangePrompt('')}
                    className="text-slate-400 hover:text-rose-600 inline-flex items-center gap-1 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>মুছে ফেলুন</span>
                  </button>
                )}
              </div>
              <div className="flex items-center gap-1.5 text-blue-600 font-bold">
                <Cpu className="w-3.5 h-3.5" />
                <span>টার্বো প্রসেসিং • প্রস্তুত</span>
              </div>
            </div>
          </div>
        </div>

        {/* Suggested Prompt Chips */}
        <div>
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
            {language === 'bn' ? 'প্রস্তাবিত বিষয়সমূহ:' : 'Recommended Prompts:'}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {currentCategory.quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  audio.playTick();
                  onChangePrompt(qp);
                }}
                className="text-xs minimal-pill text-slate-700 hover:text-blue-600 px-3 py-1.5 rounded-full transition cursor-pointer shadow-sm"
              >
                + {qp}
              </button>
            ))}
          </div>
        </div>

        {/* Submit Action Button */}
        <div>
          <button
            type="submit"
            disabled={isLoading}
            className={`w-full py-4 px-6 rounded-2xl font-black text-base sm:text-lg flex items-center justify-center gap-3 transition-all cursor-pointer shadow-md text-white ${
              isLoading ? 'bg-slate-400 cursor-not-allowed' : 'minimal-btn-primary'
            }`}
          >
            {isLoading ? (
              <>
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>{language === 'bn' ? 'প্রক্রিয়াকরণ চলছে…' : 'Processing request…'}</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5 stroke-[2.5]" />
                <span>{language === 'bn' ? 'ফলাফল প্রস্তুত করুন' : 'Generate Result'}</span>
                <span className="text-xs bg-white/20 text-white px-2.5 py-0.5 rounded-full font-bold ml-1 border border-white/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-white" />
                  <span>{language === 'bn' ? 'তাত্ক্ষণিক আউটপুট' : 'Instant Output'}</span>
                </span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
