import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-16 left-4 right-4 sm:left-auto sm:right-4 z-50 flex items-center justify-between gap-3 rounded-2xl bg-slate-900/90 backdrop-blur-2xl text-amber-300 px-4 py-2.5 shadow-2xl border border-amber-500/40 font-semibold text-xs sm:text-sm">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 text-amber-400 stroke-[2.2]" />
        <span>ইন্টারনেট সংযোগ বিচ্ছিন্ন। সংযোগ পুনরায় পরীক্ষা করুন।</span>
      </div>
      <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
    </div>
  );
};
