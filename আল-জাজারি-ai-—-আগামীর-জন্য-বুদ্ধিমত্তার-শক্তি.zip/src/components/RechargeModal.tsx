import React, { useState, useEffect } from 'react';
import { RechargePack } from '../types';
import { RECHARGE_PACKS } from '../data/categories';
import { audio } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  X,
  CheckCircle2,
  ArrowRight,
  Phone,
  Lock,
  AlertCircle,
  ShieldCheck,
  CreditCard,
  User,
  Mail,
  Zap,
  ArrowLeft,
  Sparkles,
} from 'lucide-react';

interface RechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRechargeSuccess: (creditsToAdd: number, packName: string) => void;
  currentCredits?: number;
  userStatus?: string;
  lastTransactionId?: string | null;
}

type PaymentMethodType = 'bkash' | 'nagad' | 'rocket' | 'cards';

export const RechargeModal: React.FC<RechargeModalProps> = ({
  isOpen,
  onClose,
  onRechargeSuccess,
  userStatus = 'PRO সক্রিয়',
  lastTransactionId,
}) => {
  // Default to popular pack (৳50 স্ট্যান্ডার্ড প্রফেশনাল)
  const [selectedPack, setSelectedPack] = useState<RechargePack>(RECHARGE_PACKS[1] || RECHARGE_PACKS[0]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethodType>('bkash');
  const [userId, setUserId] = useState('usr_default_jazari');
  const [customerName, setCustomerName] = useState('Customer Name');
  const [customerEmail, setCustomerEmail] = useState('customer@example.com');
  const [accountNumber, setAccountNumber] = useState('01711111111');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [recentPackName, setRecentPackName] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Auto-fill customer details from Supabase Auth session / user profile whenever available
  useEffect(() => {
    if (!isOpen) return;

    const fetchUserProfile = async () => {
      try {
        const res = await fetch('/api/payment/user-status');
        if (res.ok) {
          const data = await res.json();
          if (data.userProfile) {
            if (data.userProfile.id) {
              setUserId(data.userProfile.id);
            }
            if (data.userProfile.name && data.userProfile.name.trim()) {
              setCustomerName(data.userProfile.name);
            }
            if (data.userProfile.email && data.userProfile.email.trim()) {
              setCustomerEmail(data.userProfile.email);
            }
            if (data.userProfile.phone && data.userProfile.phone.trim()) {
              setAccountNumber(data.userProfile.phone);
            }
          }
        }
      } catch (err) {
        console.warn('Could not auto-fill user profile from database:', err);
      }
    };

    fetchUserProfile();
  }, [isOpen]);

  if (!isOpen) return null;

  // Active SSLCommerz API Gateway Handler
  const handleInitiateSSLCommerz = async () => {
    if (!accountNumber || accountNumber.trim().length < 11) {
      setErrorMessage('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর প্রদান করুন।');
      return;
    }

    setErrorMessage(null);
    setIsProcessing(true);
    audio.playTick();

    try {
      const response = await fetch('/api/payment/sslcommerz/init', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          packageId: selectedPack.id,
          packageName: selectedPack.name,
          amount: selectedPack.price,
          credits: selectedPack.credits,
          userId: userId || 'usr_default_jazari',
          customerName: customerName.trim() || 'Valued Customer',
          customerEmail: customerEmail.trim() || 'customer@example.com',
          customerPhone: accountNumber.trim(),
          paymentChannel: paymentMethod,
          customerAddress: 'Dhaka',
          customerCity: 'Dhaka',
        }),
      });

      const data = await response.json();

      if (data.success && data.gatewayUrl) {
        // Redirect to SSLCommerz Payment Gateway
        window.location.href = data.gatewayUrl;
      } else {
        setErrorMessage(data.error || 'পেমেন্ট গেটওয়েতে সংযোগ করা যায়নি। অনুগ্রহ করে পুনরায় চেষ্টা করুন।');
        setIsProcessing(false);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'সার্ভার সংযোগে ত্রুটি';
      setErrorMessage('পেমেন্ট গেটওয়ে এরর: ' + msg);
      setIsProcessing(false);
    }
  };

  return (
    /* 100% Full-Screen Dedicated View */
    <div className="fixed inset-0 z-50 w-full h-full bg-slate-900/50 backdrop-blur-md flex flex-col overflow-hidden animate-fadeIn">
      <div className="w-full h-full min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col overflow-y-auto text-left relative">
        
        {/* Clean Sticky Header Bar without debug badges */}
        <header className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-b border-slate-200/90 dark:border-slate-800 px-4 sm:px-8 py-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                audio.playTick();
                onClose();
              }}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 transition cursor-pointer flex items-center gap-1.5 font-bold text-xs"
              title="ফিরে যান"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">ফিরে যান</span>
            </button>

            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-tight">
                প্যাকেজসমূহ ও অফার পেজ
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">
                আল-জাজারি এআই প্রফেশনাল মেম্বারশিপ ও ক্লাউড কোটা
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>SSLCommerz সুরক্ষিত গেটওয়ে</span>
            </div>

            <button
              onClick={() => {
                audio.playTick();
                onClose();
              }}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Scrollable Content Body with bottom padding for sticky checkout button */}
        <div className="max-w-2xl mx-auto w-full px-4 sm:px-6 py-6 space-y-6 flex-1 pb-32">
          {isSuccess ? (
            <div className="py-16 text-center space-y-5 bg-white dark:bg-slate-900 rounded-3xl p-8 border border-emerald-200 dark:border-emerald-900 shadow-xl max-w-lg mx-auto my-auto">
              <div className="w-20 h-20 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 border-2 border-emerald-300 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-12 h-12 stroke-[2.2]" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">পেমেন্ট সফল হয়েছে!</h3>
                <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
                  আপনার অ্যাকাউন্ট সফলভাবে 'PRO সক্রিয়' স্ট্যাটাসে আপডেট করা হয়েছে।
                </p>
                <p className="text-xs text-slate-500">
                  প্যাকেজ: {recentPackName}
                </p>
              </div>
              <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs text-blue-700 dark:text-blue-300 font-bold">
                স্ট্যাটাস: <span className="text-blue-900 dark:text-blue-200">PRO সক্রিয় • সীমাহীন অ্যাক্সেস</span>
              </div>
            </div>
          ) : (
            <>
              {/* Introduction Banner */}
              <div className="bg-gradient-to-br from-blue-600 via-indigo-600 to-indigo-700 rounded-3xl p-5 sm:p-7 text-white shadow-xl relative overflow-hidden">
                <div className="relative z-10 space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold text-white border border-white/20">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>এক্সক্লুসিভ অফার ও সীমাহীন অ্যাক্সেস</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black tracking-tight">
                    আপনার প্রয়োজন অনুযায়ী সেরা প্যাকেজ বেছে নিন
                  </h3>
                  <p className="text-xs sm:text-sm text-blue-100 font-medium leading-relaxed max-w-lg">
                    সরাসরি SSLCommerz পেমেন্ট গেটওয়ের মাধ্যমে তাৎক্ষণিক এক্টিভেশন। উচ্চগতির AI মডেল ও অগ্রাধিকার সেবা।
                  </p>
                </div>
              </div>

              {/* 5 Distinct Rich Package Offers */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                    প্যাকেজ নির্বাচন করুন (৫টি সমৃদ্ধ অফার):
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">ভ্যাট অন্তর্ভুক্ত</span>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {RECHARGE_PACKS.map((pack) => {
                    const isSelected = selectedPack.id === pack.id;
                    return (
                      <div
                        key={pack.id}
                        onClick={() => {
                          audio.playTick();
                          setSelectedPack(pack);
                        }}
                        className={`relative p-4 sm:p-5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between gap-4 ${
                          isSelected
                            ? 'bg-blue-50/90 dark:bg-blue-950/40 border-blue-600 shadow-md ring-2 ring-blue-500/30'
                            : 'bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/60 border-slate-200 dark:border-slate-800 shadow-xs'
                        }`}
                      >
                        {pack.popular && (
                          <div className="absolute -top-3 right-5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-sm">
                            ★ সর্বাধিক জনপ্রিয়
                          </div>
                        )}
                        {pack.bestValue && (
                          <div className="absolute -top-3 right-5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-sm">
                            ★ সেরা ভ্যালু
                          </div>
                        )}

                        <div className="flex items-center gap-3.5 min-w-0">
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                              isSelected ? 'border-blue-600 bg-blue-600' : 'border-slate-300 dark:border-slate-600'
                            }`}
                          >
                            {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                                {pack.name}
                              </span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                {pack.quotaLabel}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium">
                              {pack.tagline}
                            </p>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              {pack.terms}
                            </p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white leading-none">
                            ৳ {pack.price}
                          </div>
                          <span className="text-[10px] text-slate-400 font-bold">BDT</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Bank Card & MFS Payment Integration */}
              <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3.5 shadow-xs">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                      পেমেন্ট মাধ্যম নির্বাচন করুন:
                    </span>
                    <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      <span>নিরাপদ গেটওয়ে</span>
                    </span>
                  </div>

                  {/* Subtle Badge under payment methods */}
                  <div className="p-2 rounded-xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-800/60 text-[11px] text-blue-800 dark:text-blue-300 font-bold flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>সব ধরনের ব্যাংক কার্ড (ডেবিট/ক্রেডিট) ও মোবাইল ব্যাংকিং সমর্থিত</span>
                  </div>
                </div>

                {/* Payment Channels Grid */}
                <div className="grid grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      audio.playTick();
                      setPaymentMethod('bkash');
                    }}
                    className={`p-3 rounded-2xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      paymentMethod === 'bkash'
                        ? 'bg-[#D12053]/10 border-[#D12053] text-[#D12053] font-bold shadow-sm ring-2 ring-[#D12053]/40'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <span className="w-3 h-3 rounded-full bg-[#D12053]" />
                    <span className="text-xs font-bold">bKash</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      audio.playTick();
                      setPaymentMethod('nagad');
                    }}
                    className={`p-3 rounded-2xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      paymentMethod === 'nagad'
                        ? 'bg-[#EA5A24]/10 border-[#EA5A24] text-[#EA5A24] font-bold shadow-sm ring-2 ring-[#EA5A24]/40'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <span className="w-3 h-3 rounded-full bg-[#EA5A24]" />
                    <span className="text-xs font-bold">Nagad</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      audio.playTick();
                      setPaymentMethod('rocket');
                    }}
                    className={`p-3 rounded-2xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      paymentMethod === 'rocket'
                        ? 'bg-[#8C3494]/10 border-[#8C3494] text-[#8C3494] font-bold shadow-sm ring-2 ring-[#8C3494]/40'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <span className="w-3 h-3 rounded-full bg-[#8C3494]" />
                    <span className="text-xs font-bold">Rocket</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      audio.playTick();
                      setPaymentMethod('cards');
                    }}
                    className={`p-3 rounded-2xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      paymentMethod === 'cards'
                        ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-600 text-blue-700 dark:text-blue-300 font-bold shadow-sm ring-2 ring-blue-500/40'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold">ব্যাংক কার্ড</span>
                  </button>
                </div>

                {/* Supported Card Brands Pill */}
                {paymentMethod === 'cards' && (
                  <div className="flex items-center justify-center gap-2 pt-1 text-[11px] font-bold text-slate-500">
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">Visa</span>
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">Mastercard</span>
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">AMEX</span>
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">DBBL Nexus</span>
                  </div>
                )}

                {/* Customer Details Form (Auto-filled from Supabase / Profile) */}
                <div className="pt-2.5 space-y-2.5 border-t border-slate-100 dark:border-slate-800">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1 mb-1">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>গ্রাহকের নাম:</span>
                      </label>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-blue-500 text-slate-900 dark:text-white text-xs rounded-xl px-3 py-2.5 focus:outline-none"
                        placeholder="আপনার নাম"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1 mb-1">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <span>ইমেইল:</span>
                      </label>
                      <input
                        type="email"
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-blue-500 text-slate-900 dark:text-white text-xs rounded-xl px-3 py-2.5 focus:outline-none"
                        placeholder="yourname@example.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center justify-between mb-1">
                      <span className="flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5 text-blue-600" />
                        <span>
                          {paymentMethod === 'cards'
                            ? 'যোগাযোগের মোবাইল নম্বর (ওটিপি ও নিশ্চিতকরণ):'
                            : `মোবাইল নম্বর (${paymentMethod.toUpperCase()} পেমেন্ট নম্বর):`}
                        </span>
                      </span>
                    </label>
                    <input
                      type="tel"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="01XXXXXXXXX"
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-blue-500 text-slate-900 dark:text-white text-xs rounded-xl px-3 py-2.5 font-mono tracking-wider focus:outline-none"
                      maxLength={11}
                    />
                  </div>

                  {errorMessage && (
                    <p className="text-xs text-rose-600 flex items-center gap-1.5 font-semibold pt-1">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{errorMessage}</span>
                    </p>
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* 
          Sticky Bottom Checkout Bar
          Always readily visible and accessible as user browses packages
        */}
        {!isSuccess && (
          <div className="sticky bottom-0 z-30 w-full bg-white/95 dark:bg-slate-900/95 border-t border-slate-200 dark:border-slate-800 p-4 sm:p-5 backdrop-blur-xl shadow-2xl">
            <div className="max-w-2xl mx-auto space-y-2">
              <button
                onClick={handleInitiateSSLCommerz}
                disabled={isProcessing}
                className="w-full py-4 px-6 rounded-2xl minimal-btn-primary text-white font-black text-sm sm:text-base shadow-lg flex items-center justify-center gap-2.5 transition cursor-pointer disabled:opacity-50 active:scale-98"
              >
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>SSLCommerz গেটওয়ে সংযোগ হচ্ছে…</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 fill-white text-white" />
                    <span>প্যাকেজ কিনুন / আপগ্রেড করুন (৳ {selectedPack.price})</span>
                    <ArrowRight className="w-4 h-4 stroke-[2.2]" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                <span>SSLCommerz 128-bit SSL এনক্রিপশন • ব্যাংক কার্ড ও এমএফএস সমর্থিত</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
